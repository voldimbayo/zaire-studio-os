# Changelog — ZAÏRE STUDIO OS

Toutes les modifications notables de **ZAÏRE STUDIO OS** sont documentées dans ce fichier.
Le format est basé sur [Keep a Changelog](https://keepachangelog.com/fr/1.1.0/) et le projet adhère au [Semantic Versioning](https://semver.org/lang/fr/).

## [1.0.0] - 2026-11-25

### Ajouté
- **Phase 1 (`research/`)** : Référentiel technique exhaustif (46 domaines, 12 axes), méthodologies industrielles vérifiées (Rockstar, Ubisoft, CD Projekt Red, Insomniac, Naughty Dog, Guerrilla), registre de 20 sources vérifiées (`source-registry.csv` : `SRC-001` à `SRC-020`) et analyse d'écarts (`research-gaps.md`).
- **Phase 2 (`architecture/`)** : Architecture système 3 couches (Direction Centrale, 8 Départements / 50 Skills Métiers, Knowledge Management Engine), protocole d'orchestration DAG, graphe de dépendances acyclique et standards de qualité.
- **Phase 3 (`skills/`, `knowledge/`, `tools/`, `schemas/`, `templates/`, `tests/`, `docs/`, `releases/`)** :
  - Base de connaissances Single Source of Truth (`knowledge/`) avec registre d'entités typé (33 entités fondatrices), journal d'audit de statuts, bible de Kinshasa, glossaire Lingala/Français Unicode (`ɛ`, `ɔ`) et budgets techniques UE5.
  - Schémas de validation formels (`schemas/`) et modèles transversaux (`templates/`).
  - Implémentation complète des **57 Agent Skills** (`00-direction` à `08-production-quality`) avec `SKILL.md`, `references/`, `templates/`, `examples/` et 9 scripts d'audit/simulation dédiés.
- **Phase 4 (`audit/`, durcissement `tools/` & packaging complet `releases/`)** :
  - Harnais d'exécution automatisé des **5 Scénarios Fonctionnels** (`tools/run_functional_scenarios.py`).
  - Dossier complet d'audit qualité dans `audit/` : `structural-audit.md`, `technical-audit.md`, `functional-audit.md`, `source-verification.md`, `known-limitations.md`, `final-report.md`.
  - Génération des **9 archives ZIP départementales** (`releases/departments/*.zip`) en complément des **57 archives ZIP individuelles Claude.ai** (`releases/skills/*.zip`) et de l'archive globale (`releases/zaire-studio-os-v1.0.0-full.zip`).
  - Guides d'exploitation : `docs/claude-ai-installation-guide.md`, `docs/update-guide.md` et `docs/compatibility-matrix.md`.

### Corrigé (Audit Phase 4)
- `DEF-01` : Alignement strict des références sources sur `SRC-001..SRC-020` dans `PRD-03` et contrôle regex automatique des références `SRC-*` dans `tools/lint_skills.py` et `tools/validate_registry.py`.
- `DEF-02` : Contrôle de parité exacte entre `metadata.upstream_dependencies` sur disque et `CANONICAL_SKILLS`.
- `DEF-03` : Intégration de la matrice complète des 57 skills et du tri par strates (`0 -> 5`) dans `dir-01-studio-orchestrator/scripts/build_dag_plan.py` avec rejet explicite de tout ID inconnu.
- `DEF-04` : Uniformisation de l'argument CLI `--file` sur tous les scripts validateurs embarqués (`ART-04`, `AUD-04`, `ENG-07`, `PRD-06`).
