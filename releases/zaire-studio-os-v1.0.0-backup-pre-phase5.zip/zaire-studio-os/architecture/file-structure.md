# Architecture des Fichiers & Répertoires — ZAÏRE STUDIO OS (`file-structure.md`)

Cette arborescence définit l'organisation complète du dépôt **ZAÏRE STUDIO OS** pour l'implémentation de la Phase 3 (génération des skills et de la base de connaissances).

```text
zaire-studio-os/
├── README.md                                # Point d'entrée global du système
├── CLAUDE.md / AGENTS.md                    # Instructions globales d'orchestration pour les agents IA
│
├── research/                                # [PHASE 1 - VALIDÉE] Base documentaire vérifiée
│   ├── README.md
│   ├── research-index.md
│   ├── industry-methodologies.md
│   ├── technical-reference.md
│   ├── skills-discovery.md
│   ├── skills-coverage-matrix.md
│   ├── research-gaps.md
│   ├── source-registry.csv
│   └── source-registry.md
│
├── architecture/                            # [PHASE 2 - EN COURS] Architecture système & contrats
│   ├── system-architecture.md
│   ├── department-map.md
│   ├── skills-catalog.md
│   ├── skill-dependencies.md
│   ├── orchestration-protocol.md
│   ├── knowledge-management.md
│   ├── quality-standards.md
│   └── file-structure.md
│
├── knowledge/                               # [PHASE 3] Single Source of Truth (Couche 2)
│   ├── entities-registry.csv                # Registre maître (CHR, FAM, ORG, DST, LOC, MSN, ITM, VEH, SYS)
│   ├── status-audit-log.csv                 # Historique des transitions (PROPOSED -> CONFIRMED / BLOCKED)
│   ├── world-bible/
│   │   ├── kinshasa-districts.md            # Référentiel des communes (Gombe, Matonge, Limete, Kalamu...)
│   │   ├── cultural-guidelines.md           # Codes sociaux, musique, architecture, authenticité RDC
│   │   └── lingala-french-glossary.csv      # Lexique normalisé multilingue (support Unicode ɛ, ɔ)
│   └── technical-specs/
│       ├── spatial-metrics.md               # Gabarits personnage, caméra, couverts, voirie
│       ├── performance-budgets.csv          # Budgets CPU/GPU/RAM/VRAM par sous-système UE5
│       └── gameplay-tags-taxonomy.csv       # Arborescence officielle des Gameplay Tags UE5
│
├── skills/                                  # [PHASE 3] 57 Agent Skills (7 Direction + 50 Métiers)
│   ├── 00-direction/                        # Couche 0 : Direction Centrale
│   │   ├── dir-01-studio-orchestrator/
│   │   │   ├── SKILL.md
│   │   │   ├── references/
│   │   │   └── assets/
│   │   ├── dir-02-executive-producer/
│   │   ├── dir-03-creative-director/
│   │   ├── dir-04-technical-director/
│   │   ├── dir-05-lead-game-designer/
│   │   ├── dir-06-documentation-director/
│   │   └── dir-07-quality-director/
│   │
│   ├── 01-narrative/                        # Département Narrative (NAR-01 à NAR-06)
│   │   ├── nar-01-narrative-architect/
│   │   ├── nar-02-screenwriter/
│   │   ├── nar-03-character-writer/
│   │   ├── nar-04-dialogue-designer/
│   │   ├── nar-05-lore-manager/
│   │   └── nar-06-continuity-editor/
│   │
│   ├── 02-world-design/                     # Département World Design (WLD-01 à WLD-06)
│   │   ├── wld-01-worldbuilding-architect/
│   │   ├── wld-02-cultural-researcher/
│   │   ├── wld-03-urban-researcher/
│   │   ├── wld-04-open-world-designer/
│   │   ├── wld-05-level-designer/
│   │   └── wld-06-environment-designer/
│   │
│   ├── 03-game-design/                      # Département Game Design (GD-01 à GD-07)
│   │   ├── gd-01-game-systems-designer/
│   │   ├── gd-02-mission-designer/
│   │   ├── gd-03-economy-designer/
│   │   ├── gd-04-progression-designer/
│   │   ├── gd-05-combat-designer/
│   │   ├── gd-06-vehicle-designer/
│   │   └── gd-07-ui-ux-designer/
│   │
│   ├── 04-ai-simulation/                    # Département AI & Simulation (AI-01 à AI-04)
│   │   ├── ai-01-npc-ai-architect/
│   │   ├── ai-02-crowd-simulation-specialist/
│   │   ├── ai-03-traffic-ai-specialist/
│   │   └── ai-04-decision-systems-designer/
│   │
│   ├── 05-art-animation/                    # Département Art & Animation (ART-01 à ART-09)
│   │   ├── art-01-art-director/
│   │   ├── art-02-environment-artist/
│   │   ├── art-03-character-artist/
│   │   ├── art-04-3d-pipeline-specialist/
│   │   ├── art-05-animation-specialist/
│   │   ├── art-06-motion-capture-specialist/
│   │   ├── art-07-lighting-specialist/
│   │   ├── art-08-technical-artist/
│   │   └── art-09-vfx-specialist/
│   │
│   ├── 06-audio-localization/               # Département Audio & Localization (AUD-01 à AUD-04)
│   │   ├── aud-01-audio-director/
│   │   ├── aud-02-sound-designer/
│   │   ├── aud-03-music-designer/
│   │   └── aud-04-voice-localization-specialist/
│   │
│   ├── 07-engineering/                      # Département Engineering (ENG-01 à ENG-08)
│   │   ├── eng-01-unreal-engine-specialist/
│   │   ├── eng-02-gameplay-programmer/
│   │   ├── eng-03-tools-programmer/
│   │   ├── eng-04-houdini-specialist/
│   │   ├── eng-05-physics-engineer/
│   │   ├── eng-06-rendering-engineer/
│   │   ├── eng-07-performance-engineer/
│   │   └── eng-08-build-engineer/
│   │
│   └── 08-production-quality/               # Département Production & Quality (PRD-01 à PRD-06)
│       ├── prd-01-production-planner/
│       ├── prd-02-risk-manager/
│       ├── prd-03-documentation-specialist/
│       ├── prd-04-qa-architect/
│       ├── prd-05-test-engineer/
│       └── prd-06-accessibility-specialist/
│
└── tools/                                   # [PHASE 3] Scripts de validation de l'écosystème
    ├── validate_registry.py                 # Vérifie l'unicité des IDs et les statuts dans knowledge/
    ├── check_dag_cycles.py                  # Vérifie l'absence de cycles dans les dépendances de skills
    └── lint_skills.py                       # Vérifie la conformité structurelle de chaque SKILL.md
```

---

## Structure Interne Standardisée d'un Répertoire Skill
Chaque dossier de skill sous `skills/<pole>/<skill-id>/` suit strictement cette anatomie :
```text
<skill-id>/
├── SKILL.md                  # Frontmatter YAML (name, description, id, department, inputs, outputs) + Instructions
├── references/               # Checklists techniques, règles métier et extraits issus de research/
│   └── domain-guidelines.md
└── assets/                   # Modèles de livrables prêts à l'emploi (Markdown, CSV ou JSON)
    └── deliverable-template.md
```
