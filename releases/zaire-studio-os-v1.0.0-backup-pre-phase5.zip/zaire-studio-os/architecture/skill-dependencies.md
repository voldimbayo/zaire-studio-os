# Graphe des Dépendances Inter-Skills (`skill-dependencies.md`)

## 1. Règle Anti-Cycles (DAG Strict)
L'architecture de **ZAÏRE STUDIO OS** interdit toute dépendance circulaire directe entre skills métiers. Les flux de production suivent un **Graphe Orienté Acyclique (DAG)** en 6 strates. Lorsqu'un skill aval détecte une anomalie sur un livrable amont (ex. `PRD-05` détecte une chute de FPS dans un quartier généré par `ENG-04`), il émet un ticket d'événement (`BLOCKED` ou `REVISION_REQUEST`) capté par le `Studio Orchestrator` (`DIR-01`), qui ouvre un nouveau cycle d'itération contrôlé.

---

## 2. Diagramme de Flux Principal (Strates 0 à 5)

```
[STRATE 0 : DIRECTION & CADRAGE]
  DIR-02 (Exec Prod) + DIR-03 (Creative Dir) + DIR-04 (Tech Dir) + DIR-05 (Lead GD)
          |
          v
[STRATE 1 : FONDATIONS CULTURELLES, URBAINES & SYSTÉMIQUES]
  WLD-02 (Cultural Res) ---> WLD-01 (Worldbuilding) ---> NAR-01 (Narrative Arch)
  WLD-03 (Urban Res) ------> WLD-04 (Open World) ------> GD-01 (Game Systems)
  ART-01 (Art Director) ---> ART-04 (3D Pipeline) -----> ENG-01 (UE5 Specialist)
  AUD-01 (Audio Director)
          |
          v
[STRATE 2 : CONCEPTION DÉTAILLÉE (MISSIONS, PERSONNAGES, MÉCANIQUES)]
  NAR-03 (Char Writer) & NAR-05 (Lore Mgr) ---> NAR-02 (Screenwriter) ---> NAR-04 (Dialogue Des)
  GD-02 (Mission Des) + GD-03 (Economy) + GD-04 (Progression) + GD-05 (Combat) + GD-06 (Vehicle) + GD-07 (UI/UX)
  WLD-05 (Level Designer) ---> WLD-06 (Environment Designer)
          |
          v
[STRATE 3 : PRODUCTION DE CONTENU & SIMULATION]
  ART-02 (Env Art) + ART-03 (Char Art) + ART-06 (MoCap) ---> ART-05 (Animation)
  ART-07 (Lighting) + ART-08 (Tech Art) + ART-09 (VFX)
  AI-01 (NPC AI) + AI-02 (Crowd Sim) + AI-03 (Traffic AI) + AI-04 (Decision Systems)
  AUD-02 (Sound Des) + AUD-03 (Music Des) + AUD-04 (Voice & L10n)
          |
          v
[STRATE 4 : INGÉNIERIE D'INTÉGRATION, PROCÉDURAL & OPTIMISATION]
  ENG-02 (Gameplay Prog) + ENG-03 (Tools Prog) + ENG-04 (Houdini) + ENG-05 (Physics)
  ENG-06 (Rendering Eng) ---> ENG-07 (Performance Eng) ---> ENG-08 (Build Eng)
          |
          v
[STRATE 5 : AUDIT, VALIDATION & CERTIFICATION]
  NAR-06 (Continuity Ed) + PRD-06 (Accessibility) + PRD-04 (QA Arch) + PRD-05 (Test Eng)
  PRD-03 (Documentation Spec) ---> DIR-06 (Doc Dir) & DIR-07 (Quality Dir) => [CONFIRMED]
```

---

## 3. Matrice des Dépendances Critiques (Inputs / Outputs)

| Skill Aval | Dépend de (Skills Amont) | Artefact Transmis (Handoff) | Condition de Déclenchement |
| :--- | :--- | :--- | :--- |
| `WLD-01` (Worldbuilding) | `DIR-03`, `WLD-02`, `WLD-03` | Dossiers culturels & morphologie urbaine | Statut `PROPOSED` ou `CONFIRMED` |
| `NAR-01` (Narrative Arch) | `DIR-03`, `WLD-01`, `WLD-02` | World Bible & identité des communes (`DST-*`) | Piliers créatifs validés |
| `NAR-02` (Screenwriter) | `NAR-01`, `NAR-03`, `GD-02` | Architecture actes, fiches `CHR-*`, structure `MSN-*` | IDs `CHR-*` et `MSN-*` enregistrés |
| `NAR-04` (Dialogue Des) | `NAR-02`, `NAR-03`, `GD-02` | Scripts de scènes & variables d'état de quête | Beat sheet validée |
| `WLD-04` (Open World) | `WLD-01`, `WLD-03`, `GD-01`, `DIR-04` | Typologie urbaine, Core Loops, budgets streaming | Grille World Partition définie |
| `WLD-05` (Level Designer) | `WLD-04`, `GD-02`, `GD-05`, `ART-05` | Briefs POI/Mission & métriques déplacement/combat | Métriques spatiales gelées |
| `WLD-06` (Env Designer) | `WLD-05`, `ART-01`, `WLD-02`, `WLD-03` | Blockouts gameplay validés & Art Bible | Playtest blockout réussi |
| `ART-02` (Env Artist) | `WLD-06`, `ART-04` | Environment Briefs & normes 3D/Nanite | Règles Texel Density publiées |
| `ART-03` (Character Art) | `NAR-03`, `WLD-02`, `ART-01`, `ART-04` | Fiches personnages, références vestimentaires, normes 3D | Concept validé par `ART-01` |
| `ART-05` (Animation) | `WLD-05`, `GD-05`, `ART-06` | Métriques terrain, frames combat, MoCap nettoyée | Squelette maître validé |
| `AI-02` (Crowd Sim) | `WLD-04`, `ART-03`, `DIR-04` | Densité par quartier, kits PNJ modulaires, budget CPU | Architecture Mass Entity prête |
| `AI-03` (Traffic AI) | `ENG-04`, `GD-06`, `WLD-03` | Splines routières OSM/Houdini & profils véhicules | Réseau ZoneGraph généré |
| `ENG-02` (Gameplay Prog) | `GD-01`..`GD-06`, `ENG-01` | GDD systémiques & architecture C++/GAS | Gameplay Tags enregistrés |
| `ENG-04` (Houdini) | `WLD-03`, `ART-02`, `AI-03` | Règles urbaines, kits modulaires, specs ZoneGraph | HDA testé sur tuile pilote |
| `ENG-07` (Performance) | `ENG-01`..`ENG-06`, `ART-07`, `ART-09` | Scènes assemblées, shaders, éclairage, VFX | Build jouable généré (`ENG-08`) |
| `AUD-04` (Voice & L10n) | `NAR-04`, `GD-07`, `WLD-02` | Dialogues finaux, textes UI, glossaire lingala | String Freeze prononcé |
| `PRD-05` (Test Eng) | `PRD-04`, `ENG-07`, `ENG-08` | Plans de test, budgets perf, pipeline CI/CD | Build nocturne disponible |
| `DIR-06` / `DIR-07` | `NAR-06`, `PRD-03`, `PRD-04`, `PRD-06` | Audits continuité, documentation, QA et XAG | 100 % des critères DoD remplis |
