"""Tests d'intégration complets de ZAÏRE STUDIO OS :
- Validation des 57 SKILL.md (frontmatter YAML, sections obligatoires, absence de phrases creuses).
- Contrôle d'existence et de sécurité des chemins de toutes les références, templates, exemples et scripts.
- Exécution unitaire réelle des 9 scripts métier embarqués dans les skills.
- Vérification de l'intégrité des 57 archives ZIP individuelles Claude.ai et de l'archive globale.
"""

from __future__ import annotations

import subprocess
import sys
import unittest
import zipfile
from pathlib import Path

from tools import WORKSPACE_ROOT
from tools.check_dag_cycles import build_disk_graph, check_all_dags, compute_topological_order
from tools.lint_skills import lint_skills_in_workspace
from tools.registry_data import CANONICAL_SKILLS


class TestZaireStudioOSSystem(unittest.TestCase):
    def test_all_57_skills_lint_and_references(self) -> None:
        count, errors = lint_skills_in_workspace(WORKSPACE_ROOT, require_all_57=True)
        self.assertEqual(count, 57, f"Attendu 57 skills, trouvé {count}")
        self.assertEqual(errors, [], f"Erreurs de linting : {errors}")

    def test_disk_dag_has_57_nodes_and_zero_cycles(self) -> None:
        disk_graph = build_disk_graph(WORKSPACE_ROOT)
        self.assertEqual(len(disk_graph), 57)
        ordered, cycles = compute_topological_order(disk_graph)
        self.assertEqual(cycles, [])
        self.assertEqual(len(ordered), 57)
        self.assertEqual(check_all_dags(WORKSPACE_ROOT), [])

    def test_department_counts_match_architecture(self) -> None:
        expected_counts = {
            "00-direction": 7,
            "01-narrative": 6,
            "02-world-design": 6,
            "03-game-design": 7,
            "04-ai-simulation": 4,
            "05-art-animation": 9,
            "06-audio-localization": 4,
            "07-engineering": 8,
            "08-production-quality": 6,
        }
        skills_root = WORKSPACE_ROOT / "skills"
        for dept, expected in expected_counts.items():
            dept_dir = skills_root / dept
            self.assertTrue(dept_dir.exists(), f"Département manquant : {dept}")
            actual_dirs = [p for p in dept_dir.iterdir() if p.is_dir() and (p / "SKILL.md").exists()]
            self.assertEqual(
                len(actual_dirs),
                expected,
                f"Département {dept}: attendu {expected} skills, trouvé {len(actual_dirs)}",
            )

    def test_embedded_skill_scripts_execute_successfully(self) -> None:
        scripts_to_run = [
            (
                WORKSPACE_ROOT
                / "skills/00-direction/dir-01-studio-orchestrator/scripts/build_dag_plan.py",
                ["--skills", "WLD-02,WLD-03,WLD-01,NAR-01,GD-02,NAR-02,NAR-06"],
            ),
            (
                WORKSPACE_ROOT
                / "skills/01-narrative/nar-04-dialogue-designer/scripts/validate_dialogue_json.py",
                [],
            ),
            (
                WORKSPACE_ROOT
                / "skills/02-world-design/wld-05-level-designer/scripts/check_spatial_metrics.py",
                [],
            ),
            (
                WORKSPACE_ROOT
                / "skills/03-game-design/gd-03-economy-designer/scripts/simulate_economy.py",
                ["--hours", "40"],
            ),
            (
                WORKSPACE_ROOT
                / "skills/04-ai-simulation/ai-02-crowd-simulation-specialist/scripts/check_mass_budget.py",
                [],
            ),
            (
                WORKSPACE_ROOT
                / "skills/05-art-animation/art-04-3d-pipeline-specialist/scripts/check_3d_standards.py",
                [],
            ),
            (
                WORKSPACE_ROOT
                / "skills/06-audio-localization/aud-04-voice-localization-specialist/scripts/check_l10n_unicode.py",
                [],
            ),
            (
                WORKSPACE_ROOT
                / "skills/07-engineering/eng-07-performance-engineer/scripts/check_perf_budget.py",
                [],
            ),
            (
                WORKSPACE_ROOT
                / "skills/08-production-quality/prd-06-accessibility-specialist/scripts/check_xag_compliance.py",
                [],
            ),
        ]
        for script_path, extra_args in scripts_to_run:
            self.assertTrue(script_path.exists(), f"Script manquant : {script_path}")
            proc = subprocess.run(
                [sys.executable, str(script_path), *extra_args],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(
                proc.returncode,
                0,
                f"Échec d'exécution de {script_path.name}: stdout={proc.stdout} stderr={proc.stderr}",
            )

    def test_zip_releases_packaging_and_integrity(self) -> None:
        skills_zip_dir = WORKSPACE_ROOT / "releases" / "skills"
        self.assertTrue(skills_zip_dir.exists())

        zip_files = sorted(skills_zip_dir.glob("*.zip"))
        self.assertEqual(len(zip_files), 57, f"Attendu 57 archives ZIP individuelles, trouvé {len(zip_files)}")

        for spec in CANONICAL_SKILLS:
            zpath = skills_zip_dir / f"{spec.slug}.zip"
            self.assertTrue(zpath.exists(), f"Archive ZIP manquante pour {spec.slug}")
            with zipfile.ZipFile(zpath, mode="r") as zf:
                self.assertIsNone(zf.testzip(), f"Archive ZIP corrompue : {zpath}")
                namelist = zf.namelist()
                self.assertIn(f"{spec.slug}/SKILL.md", namelist)
                self.assertTrue(any(n.startswith(f"{spec.slug}/references/") for n in namelist))
                self.assertTrue(any(n.startswith(f"{spec.slug}/templates/") for n in namelist))
                self.assertTrue(any(n.startswith(f"{spec.slug}/examples/") for n in namelist))

        full_zip = WORKSPACE_ROOT / "releases" / "zaire-studio-os-v1.0.0-full.zip"
        self.assertTrue(full_zip.exists(), "Archive globale du système manquante.")
        with zipfile.ZipFile(full_zip, mode="r") as zf:
            self.assertIsNone(zf.testzip(), "Archive globale corrompue.")
            names = set(zf.namelist())
            self.assertIn("zaire-studio-os/README.md", names)
            self.assertIn("zaire-studio-os/CLAUDE.md", names)
            self.assertIn("zaire-studio-os/knowledge/entities-registry.csv", names)
            self.assertIn("zaire-studio-os/docs/skills-index.md", names)
            self.assertIn("zaire-studio-os/audit/final-report.md", names)

        depts_zip_dir = WORKSPACE_ROOT / "releases" / "departments"
        self.assertTrue(depts_zip_dir.exists(), "Répertoire releases/departments manquant.")
        dept_zips = sorted(depts_zip_dir.glob("*.zip"))
        self.assertEqual(len(dept_zips), 9, f"Attendu 9 archives ZIP départementales, trouvé {len(dept_zips)}")
        for dz in dept_zips:
            with zipfile.ZipFile(dz, mode="r") as zf:
                self.assertIsNone(zf.testzip(), f"Archive départementale corrompue : {dz}")

    def test_five_functional_scenarios_pass(self) -> None:
        from tools.run_functional_scenarios import execute_all_five_scenarios

        results = execute_all_five_scenarios()
        self.assertEqual(len(results), 5)
        for key, payload in results.items():
            self.assertEqual(
                payload.get("classification"),
                "PASS",
                f"Le scénario {key} n'a pas obtenu PASS: {payload}",
            )


if __name__ == "__main__":
    unittest.main()
