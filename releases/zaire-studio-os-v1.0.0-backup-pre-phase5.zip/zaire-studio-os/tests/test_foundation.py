"""Tests unitaires et d'intégration de la suite d'outils ZAÏRE STUDIO OS."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from tools import WORKSPACE_ROOT, YamlParseError, extract_frontmatter, parse_simple_yaml, resolve_safe_path
from tools.check_dag_cycles import build_canonical_graph, check_all_dags, compute_topological_order
from tools.registry_data import CANONICAL_SKILLS
from tools.validate_registry import validate_knowledge_base


class TestToolingFoundation(unittest.TestCase):
    def test_yaml_parser_and_frontmatter(self) -> None:
        sample = (
            "---\n"
            "name: dir-01-studio-orchestrator\n"
            'description: "Orchestrateur central du système ZAÏRE STUDIO OS."\n'
            "metadata:\n"
            "  id: DIR-01\n"
            "  stratum: 0\n"
            "  inputs:\n"
            "    - user-request\n"
            "    - entities-registry.csv\n"
            "  upstream_dependencies: []\n"
            "---\n"
            "# Corps du Skill\n"
        )
        fm, body = extract_frontmatter(sample)
        self.assertEqual(fm["name"], "dir-01-studio-orchestrator")
        self.assertEqual(fm["metadata"]["id"], "DIR-01")
        self.assertEqual(fm["metadata"]["stratum"], 0)
        self.assertEqual(fm["metadata"]["inputs"], ["user-request", "entities-registry.csv"])
        self.assertEqual(fm["metadata"]["upstream_dependencies"], [])
        self.assertEqual(body, "# Corps du Skill")

    def test_yaml_rejects_tabs_and_missing_delimiter(self) -> None:
        with self.assertRaises(YamlParseError):
            parse_simple_yaml("key:\n\t- bad_indent")
        with self.assertRaises(YamlParseError):
            extract_frontmatter("name: missing_opening_delimiter\n---\n")

    def test_safe_path_blocks_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            base = Path(tmpdir)
            valid = resolve_safe_path(base, "references/guide.md")
            self.assertTrue(str(valid).startswith(str(base.resolve())))
            with self.assertRaises(ValueError):
                resolve_safe_path(base, "../../etc/passwd")

    def test_canonical_catalog_has_57_skills_and_zero_cycles(self) -> None:
        self.assertEqual(len(CANONICAL_SKILLS), 57)
        graph = build_canonical_graph()
        ordered, cycles = compute_topological_order(graph)
        self.assertEqual(cycles, [])
        self.assertEqual(len(ordered), 57)
        self.assertEqual(check_all_dags(WORKSPACE_ROOT), [])

    def test_cycle_detection_catches_circular_dependency(self) -> None:
        cyclic_graph = {
            "A": ["B"],
            "B": ["C"],
            "C": ["A"],
        }
        _, cycles = compute_topological_order(cyclic_graph)
        self.assertEqual(cycles, ["A", "B", "C"])

    def test_knowledge_base_integrity(self) -> None:
        errors = validate_knowledge_base(WORKSPACE_ROOT)
        self.assertEqual(errors, [], f"Erreurs dans knowledge/: {errors}")


if __name__ == "__main__":
    unittest.main()
