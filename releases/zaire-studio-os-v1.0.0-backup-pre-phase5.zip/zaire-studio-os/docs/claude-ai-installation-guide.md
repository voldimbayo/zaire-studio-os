# Guide d'Installation dans Claude.ai — ZAÏRE STUDIO OS (`claude-ai-installation-guide.md`)

Ce guide explique pas à pas comment importer et utiliser les **57 Agent Skills** et la **Single Source of Truth (`knowledge/`)** de **ZAÏRE STUDIO OS** dans **Claude.ai** (Web et application Desktop).

---

## 1. Prérequis & Fichiers Préparés

Toutes les archives prêtes à l'importation se trouvent dans le répertoire `releases/` :
- **Archives individuelles de chaque skill (recommandé pour la fonctionnalité *Skills* de Claude.ai)** :
  `releases/skills/<skill-name>.zip` (57 archives autonomes contenant chacune `<skill-name>/SKILL.md`, `references/`, `templates/`, `examples/` et éventuellement `scripts/`).
- **Archives regroupées par département** :
  `releases/departments/<00-direction..08-production-quality>.zip` (9 archives départementales).

---

## 2. Étape 1 : Configurer le Projet Claude.ai ("ZAÏRE STUDIO OS — Knowledge Base")

Pour que tous les skills partagent la même **Single Source of Truth (Couche 2)** sans duplication :
1. Ouvrez **Claude.ai** et créez un nouveau Projet intitulé **`ZAÏRE STUDIO OS`**.
2. Dans le panneau **Project Knowledge (Connaissances du projet)**, importez les 8 fichiers suivants situés dans `knowledge/` et à la racine :
   - `CLAUDE.md` (Instructions globales d'orchestration et nomenclature des IDs)
   - `knowledge/entities-registry.csv` (Registre maître des entités `CHR-*`, `LOC-*`, `MSN-*`, etc.)
   - `knowledge/status-audit-log.csv` (Historique des statuts)
   - `knowledge/world-bible/kinshasa-districts.md` (Référentiel des communes de Kinshasa)
   - `knowledge/world-bible/cultural-guidelines.md` (Directives d'authenticité culturelle RDC)
   - `knowledge/world-bible/lingala-french-glossary.csv` (Glossaire certifié Lingala Unicode `ɛ`, `ɔ`)
   - `knowledge/technical-specs/spatial-metrics.md` (Gabarits UE5 : `1 UU = 1 cm`, couloirs `>= 350 cm`)
   - `knowledge/technical-specs/performance-budgets.csv` & `gameplay-tags-taxonomy.csv`

---

## 3. Étape 2 : Importer les Agent Skills (`releases/skills/*.zip`)

1. Dans Claude.ai, accédez à **Settings > Capabilities / Skills** (ou au gestionnaire de Skills de votre espace de travail) et activez **Code Execution / Analysis Tool** afin que Claude puisse exécuter les scripts Python embarqués (`scripts/*.py`).
2. Cliquez sur **Upload Skill (Importer un Skill)** et sélectionnez les archives ZIP depuis `releases/skills/`.
3. **Ordre d'importation recommandé par lots fonctionnels** :
   - **Socle Direction (Obligatoire)** : `dir-01-studio-orchestrator.zip`, `dir-03-creative-director.zip`, `dir-04-technical-director.zip`, `dir-05-lead-game-designer.zip`, `dir-06-documentation-director.zip`, `dir-07-quality-director.zip`.
   - **Lot World & Narrative** : Skills des départements `01-narrative` (`nar-01` à `nar-06`) et `02-world-design` (`wld-01` à `wld-06`).
   - **Lot Gameplay & AI** : Skills des départements `03-game-design` (`gd-01` à `gd-07`) et `04-ai-simulation` (`ai-01` à `ai-04`).
   - **Lot Art, Audio & Engineering** : Skills des départements `05-art-animation`, `06-audio-localization`, `07-engineering` et `08-production-quality`.

---

## 4. Étape 3 : Vérifier le Bon Fonctionnement dans Claude.ai

Une fois le projet ouvert, envoyez la requête de test suivante :
> *« En utilisant `dir-01-studio-orchestrator`, génère le plan DAG pour concevoir une mission secondaire de course en moto Wewa (`VEH-MOTO-WEWA-01`) dans `DST-MATONGE` sous `World.Weather.TropicalStorm`, puis exécute les contrôles de métriques spatiales et de dialogue. »*

Claude activera `dir-01-studio-orchestrator`, consultera `entities-registry.csv` dans le Project Knowledge, exécutera `scripts/build_dag_plan.py` et mobilisera séquentiellement les skills spécialisés en respectant les statuts `CONFIRMED` / `PROPOSED` / `RESEARCH_REQUIRED`.
