# Méthodologie QA par Quadrillage Open World & Tests Destructifs (`PRD-04`)

## 1. Classification des Sévérités d'Anomalies ZAÏRE STUDIO OS
- **`SEV-A (Blocker / Passage en BLOCKED immédiat)`** : Crash moteur, OOM VRAM (`> 6144 MB`), Soft-Lock de quête principal ou secondaire, perte de sauvegarde, chute à travers le sol.
- **`SEV-B (Critical)`** : Frametime P99 `> 16.6 ms` sur un parcours principal, blocage du trafic `AI-03` non résolu après `8 s`, absence de préfixe locuteur ou troncature UI (`AUD-04`/`PRD-06`).
- **`SEV-C (Major)`** : Artefact visuel Nanite/Lumen, couture de texture visible, bark désynchronisé.
- **`SEV-D (Minor / Polish)`** : Détail cosmétique mineur hors chemin principal.
