# Plan de Test QA Open World & Anti-Soft-Lock (`PRD-04`)

- **ID Plan de Test** : `QATP-[MSN/DST]-[NUM]`
- **Cible Testée** : `MSN-...` | `LOC-...` (`DST-...`)
- **Cellules World Partition Couvertes** : `[Grid_X.._Y..]`
- **Taux de Reproductibilité Exigé** : `>= 90 %`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Matrice de Couverture Fonctionnelle & Destructive
| Test Case ID | Catégorie (`NOMINAL` / `DESTRUCTIVE`) | Action Testeur / Perturbation | Résultat Attendu (Zéro Soft-Lock) | Automatisation (`PRD-05`) |
| :--- | :--- | :--- | :--- | :--- |
| `TC-001` | `DESTRUCTIVE` | `[Destruction véhicule / Fuite]` | `[Handler de récupération GD-02 actif]` | `Oui (Gauntlet)` |

## 2. Format de Ticket d'Anomalie Déterministe
- **Coordonnées UE5 (X, Y, Z cm) & Seed** : `[X=..., Y=..., Z=... | Seed=19600630]`
- **Gameplay Tags & Data Layers Actifs** : `[Liste]`
