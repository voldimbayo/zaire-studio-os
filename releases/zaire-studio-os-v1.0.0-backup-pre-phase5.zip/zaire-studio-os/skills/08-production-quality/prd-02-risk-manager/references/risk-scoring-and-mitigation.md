# Méthodologie de Cotation & Mitigation des Risques AAA (`PRD-02`)

## 1. Grille de Criticité ($S = P 	imes I$)
- **Probabilité ($1..5$)** : `1` = Rare (<10%), `3` = Possible (40-60%), `5` = Quasi-certain (>85%).
- **Impact ($1..5$)** : `1` = Mineur, `3` = Retard de sprint / Dégradation FPS locale, `5` = Blocage Jalon / Crash / Litige juridique ou rejet culturel.
- **Seuil d'Action Obligatoire** : Tout score **`>= 12`** déclenche une mesure de contingence immédiate intégrée au DAG de `DIR-01`.
