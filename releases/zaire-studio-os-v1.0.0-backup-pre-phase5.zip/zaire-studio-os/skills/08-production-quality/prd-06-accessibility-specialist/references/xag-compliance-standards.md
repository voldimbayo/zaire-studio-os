# Référentiel de Conformité Xbox Accessibility Guidelines — XAG (`PRD-06`)

## 1. Grille des Exigences XAG Obligatoires pour ZAÏRE
| Code XAG | Domaine | Exigence Technique Impérative dans ZAÏRE STUDIO OS | Skills Impliqués |
| :--- | :--- | :--- | :--- |
| **XAG 101** | Contraste & Texte | Ratio de contraste `>= 4.5:1` (UI) et `>= 7.0:1` (Sous-titres), tolérance expansion `+35 %`, police Unicode (`ɛ`, `ɔ`). | `GD-07`, `AUD-04` |
| **XAG 102** | Daltonisme & Couleur | Zéro information codée par la couleur seule (Double codage Couleur + Forme/Icône + Filtres Deutéranopie/Protanopie/Tritanopie). | `GD-07`, `ART-01` |
| **XAG 104** | Sous-titres & Audio | Préfixe locuteur `[KOFFI]`, fond réglable (`50-100 %`), taille police `28-42 px`, radar visuel des sons critiques (`BUS_SFX_CombatTelegraph`). | `AUD-04`, `AUD-01`, `GD-07` |
| **XAG 107** | Accessibilité Motrice | Remapping complet `Enhanced Input`, bascule `Hold / Toggle` pour la course/visée, remplacement des QTE par maintien continu ou auto-succès. | `ENG-02`, `GD-05`, `GD-06` |
| **XAG 108** | Cognitif & Navigation | Rappel permanent de l'objectif `MSN-*` sur le téléphone diégétique et guidage visuel optionnel par les landmarks (`SYS-WLD-LANDMARKS`). | `GD-02`, `WLD-04`, `GD-07` |
