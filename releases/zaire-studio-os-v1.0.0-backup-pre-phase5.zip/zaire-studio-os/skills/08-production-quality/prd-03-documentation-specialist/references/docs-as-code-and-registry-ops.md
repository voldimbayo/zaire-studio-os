# Procédures Docs-as-Code & Maintenance du Registre (`PRD-03`)

## 1. Les 11 Colonnes Obligatoires de `knowledge/entities-registry.csv`
1. `id` : Identifiant ASCII majuscule (`^(CHR|FAM|ORG|DST|LOC|MSN|ITM|VEH|SYS)-[A-Z0-9-]+$`).
2. `category` : `CHARACTER`, `FAMILY`, `ORGANIZATION`, `DISTRICT`, `LOCATION`, `MISSION`, `ITEM`, `VEHICLE`, `SYSTEM`.
3. `name` : Nom lisible complet.
4. `district_id` : `DST-*` ou `GLOBAL`.
5. `status` : `CONFIRMED`, `PROPOSED`, `RESEARCH_REQUIRED`, `BLOCKED`, `DEPRECATED`.
6. `owner_skill` : Code du skill propriétaire (`NAR-03`, `WLD-01`, `GD-02`...).
7. `validated_by` : Liste des valideurs séparés par `|` (`DIR-03|DIR-06`).
8. `dependencies` : Liste des IDs prérequis séparés par `|`.
9. `sources` : Références `SRC-*` issues de `research/source-registry.csv`.
10. `last_updated` : Date ISO `YYYY-MM-DD`.
11. `summary` : Description opérationnelle concise.
