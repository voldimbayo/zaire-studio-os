# Méthodologie de Planification Hybride Open World (`PRD-01`)

## 1. Chaîne Critique d'un Lieu ou d'une Mission (`LOC-*` / `MSN-*`)
1. **Sprint N-1 (Fondations Strates 1-2)** : Recherche `WLD-02`/`WLD-03` -> Design `GD-02` + Script `NAR-02` -> Blockout `WLD-05` -> Validation Playtest `DIR-05`.
2. **Sprint N (Production Strate 3)** : Environment Brief `WLD-06` -> Kits 3D `ART-02` + IA `AI-01`/`AI-02` + Dialogues/Barks `NAR-04` + SFX `AUD-02`.
3. **Sprint N+1 (Intégration & Gatekeeping Strates 4-5)** : Éclairage `ART-07` + VFX `ART-09` + Profilage P99 `ENG-07` + Tests Gauntlet `PRD-05` + Certification `DIR-06`/`DIR-07`.
