# Plan de Sprint & Matrice RACI (`PRD-01`)

- **ID Sprint** : `SPR-2026-NN`
- **Jalon Cible (`DIR-02`)** : `[Vertical Slice / Alpha / Beta / Gold]`
- **Capacité Planifiée / Buffer** : `85 % Planifié / 15 % Buffer Aléas`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Séquencement des Livrables sur le Chemin Critique
| Task ID | Livrable / Entité | Skill `R` (Responsible) | Skill `A` (Accountable) | Skills `C` (Consulted) | Strate DAG |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `TSK-...` | `[Livrable]` | `[Skill unique]` | `DIR-...` | `[Auditeurs]` | `[1..5]` |

## 2. Goulots d'Étranglement & Dépendances Surveillées
- **Verrou Blockout First** : `[État de validation WLD-05 -> ART-02]`
