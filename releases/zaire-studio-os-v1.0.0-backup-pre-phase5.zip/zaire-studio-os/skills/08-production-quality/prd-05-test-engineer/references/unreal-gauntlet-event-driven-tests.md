# Architecture des Tests Automatisés Gauntlet Sans Faux Positifs (`PRD-05`)

## 1. Règle d'Or Anti-Flakiness : Synchronisation Événementielle Pure
- **Interdit** : `AddCommand(new FDelayedFunctionLatentCommand(..., 3.0f));` (échoue si le disque ou le shader cache met 3.2s).
- **Obligatoire** : `AddCommand(new FZaireWaitForWorldPartitionIdleCommand(World));` suivi de `FZaireWaitForGameplayTagCommand(Actor, Tag)`.

## 2. Suite Nocturne Gauntlet (`ZaireNightlyAutomationSuite`)
| Suite ID | Type Gauntlet | Durée | Systèmes Couverts (`>= 80 %`) | Critère de Succès Bloquant |
| :--- | :--- | :--- | :--- | :--- |
| `GT_Smoke_BootAndPort` | `FunctionalTest` | `3.5 min` | `SYS-WLD-STREAMING`, `SYS-STEALTH`, `SYS-CMB-MELEE` | 100 % des assertions vertes, 0 crash. |
| `GT_Perf_KinshasaLoop` | `GauntletController` | `30 min` | `SYS-CROWD-MASS`, `SYS-TRAFFIC-ZONE`, `SYS-PHYS-CHAOS` | `P99 <= 16.6 ms` (`ENG-07`), `VRAM <= 6144 MB`. |
| `GT_Soak_2Hours_Traffic` | `EnduranceSoak` | `120 min` | Stabilité mémoire & Watchdog Anti-Deadlock `AI-03` | 0 deadlock routier `> 8s`, dérive RAM `< 1 %`. |
