# Règles d'Urbanisme Ludique & Pacing Open World (`WLD-04`)

## 1. Grille UE5 World Partition & Streaming
- **Taille de Cellule Standard** : `12800 cm × 12800 cm` (`128 m × 128 m`).
- **Distance Minimale Inter-Missions Majeures** : `>= 256 m` (2 cellules complètes) pour permettre le déchargement complet (`Data Layers`) de l'arène précédente lors d'une fuite en `VEH-MOTO-WEWA-01`.

## 2. Hiérarchie des Landmarks (`SYS-WLD-LANDMARKS`)
- **Tier 1 (Macro-Repères Régionaux, visibles à > 1.5 km via HLOD)** : `LOC-LIMETE-ECHANGEUR` (Tour de 210 m à l'Est), Fleuve Congo & Grues de `LOC-GOMBE-PORT` (Nord), Skyline des tours de `DST-GOMBE`.
- **Tier 2 (Repères de Commune, visibles à 300-600 m)** : `LOC-MATONGE-VICTOIRE`, château d'eau, antenne émettrice de `ORG-RADIO-KIN`.
- **Tier 3 (Micro-Repères de Rue, < 100 m)** : Fresques murales, enseignes lumineuses de ngandas, arbres remarquables.
