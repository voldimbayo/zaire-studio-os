# Morphologie Urbaine & Réseau Viaire de Kinshasa (`WLD-03`)

## 1. Hiérarchie du Réseau Routier (Standards UE5 / ZoneGraph)
1. **Artères Primaires (Boulevard du 30 Juin `LOC-GOMBE-BD30JUIN`, Boulevard Lumumba)** :
   - 2 × 3 ou 2 × 4 voies de `400 cm` chacune + terre-plein central arboré ou bétonné (`200-400 cm`) + trottoirs `400 cm`.
2. **Avenues Secondaires & Carrefours (`LOC-MATONGE-VICTOIRE`, Avenue Kasa-Vubu)** :
   - 2 × 2 voies de `350 cm` + stationnement latéral informel (`220 cm`) + trottoirs/galeries `300-600 cm`.
3. **Ruelles Tertiaires (`DST-KALAMU`, quartiers intérieurs)** :
   - Chaussée mixte asphalte dégradé / latérite compactée de `450 cm` à `600 cm` + caniveaux latéraux de `60 cm` (accès privilégié `VEH-MOTO-WEWA-01` et piétons).
