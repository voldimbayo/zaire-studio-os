# Narration Environnementale & Découpage Modulaire (`WLD-06`)

## 1. Les 3 Couches d'Habillage d'un Lieu Kinois (`LOC-*`)
1. **Couche 1 — Ossature & Patine Climatique** : Structure béton/brique, traces de ruissellement des pluies équatoriales, oxydation des tôles, poussière rouge latéritique à la base des murs (via Runtime Virtual Texturing `ART-02`).
2. **Couche 2 — Activité Sociale & Signalétique** : Enseignes peintes à la main (`NAR-05`), étals modulaires, câblages aériens, mobilier de nganda, caisses de fret portuaires.
3. **Couche 3 — Affordance Gameplay & Guidage Visuel** : Marquage chromatique subtil (bâches jaunes/bleues, éclairage fonctionnel `ART-07`, usure des rebords) sur les points de franchissement (`100 cm`) et d'escalade (`280 cm`).
