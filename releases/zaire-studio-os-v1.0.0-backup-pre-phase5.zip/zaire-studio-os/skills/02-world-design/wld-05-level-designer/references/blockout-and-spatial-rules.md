# Méthodologie Blockout First & Gabarits UE5 (`WLD-05`)

## 1. Tableau Récapitulatif des Cotes Obligatoires (`spatial-metrics.md`)
| Élément Géométrique | Cote Cible (cm) | Seuil Minimal Absolu | Justification Gameplay / Caméra |
| :--- | :--- | :--- | :--- |
| Largeur Couloir Jouable | `400 cm` | `350 cm` | Croisement 2 PNJ + rotation caméra SpringArm sans clipping. |
| Largeur Arène Mêlée (`GD-05`) | `600 cm` | `500 cm` | Espace requis pour esquives et gestion de 2 Attack Tokens. |
| Hauteur Sous Plafond | `360 cm` | `320 cm` | Évite l'écrasement vertical de la caméra 3e personne. |
| Couvert Bas (Vault / Crouch) | `100 cm` | `90 - 110 cm` | Alignement exact avec `Ability.Movement.Vault` (`ART-05`). |
| Couvert Haut (Full Cover) | `220 cm` | `200 cm` | Occultation complète de la capsule `180 cm`. |
| Inter-file Moto Wewa | `150 cm` | `130 cm` | Passage fluide de `VEH-MOTO-WEWA-01` (largeur 80 cm). |
