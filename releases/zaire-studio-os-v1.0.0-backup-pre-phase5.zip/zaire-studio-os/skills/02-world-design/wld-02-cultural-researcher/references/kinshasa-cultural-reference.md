# Référentiel Socio-Culturel & Linguistique de Kinshasa (`WLD-02`)

## 1. Phonologie & Orthographe Unicode du Lingala Kinois
Le système vocalique du lingala distingue 7 voyelles : `a, e, ɛ, i, o, ɔ, u`.
- `ɛ` (U+025B — *e ouvert*, comme dans *Kɛbá!*, *Tɔ́kɛndɛ́*).
- `ɔ` (U+0254 — *o ouvert*, comme dans *Tɔ́kɛndɛ́*, *Bilɔkɔ*).
Toute chaîne destinée à l'interface UE5 (`GD-07`) ou aux sous-titres (`AUD-04`) doit préserver ces points de code UTF-8.

## 2. Repères Sociologiques Contemporains
- **Mobilité Urbaine** : Coexistence des grands bus (`ORG-TRANSCO`), des taxis collectifs jaunes (*Ketchs*, `VEH-TAXI-JAUNE-01`) et des motos-taxis (*Wewa*, `VEH-MOTO-WEWA-01`).
- **Sociabilité** : Les *ngandas* (`LEX-011`) de Matonge et Kalamu servent de carrefours d'information, de débat et de diffusion musicale.
