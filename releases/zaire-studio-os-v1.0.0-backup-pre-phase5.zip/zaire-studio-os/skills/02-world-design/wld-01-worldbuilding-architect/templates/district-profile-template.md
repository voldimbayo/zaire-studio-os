# Profil de Commune — World Bible (`WLD-01`)

- **ID Registre** : `DST-[COMMUNE]`
- **Nom de la Commune** : `[Nom]`
- **Gameplay Tag Associé** : `World.District.[Nom]`
- **Statut** : `CONFIRMED` | `PROPOSED` | `RESEARCH_REQUIRED`

## 1. Identité Socio-Économique & Factions
- **Profil Social & Activités** : `[Description]`
- **Factions Dominantes (`ORG-*`)** : `[Liste]`
- **Landmark Directeur (`LOC-*`)** : `LOC-...`

## 2. Paramètres de Simulation & Ambiance
- **Densité Foule (`AI-02`)** : `[Jour / Nuit]`
- **Profil Trafic (`AI-03`)** : `[Types de véhicules VEH-*]`
- **Signature Visuelle (`ART-01`) & Sonore (`AUD-01`)** : `[Synthèse]`
