# Principes de Worldbuilding Macroscopique — Kinshasa (`WLD-01`)

## 1. Contraste des Strates Urbaines
- **Axe Fluvial & Institutionnel (`DST-GOMBE`)** : Pouvoir financier, ambassades, port lourd ONATRA (`LOC-GOMBE-PORT`), boulevards à 2x3 voies (`LOC-GOMBE-BD30JUIN`).
- **Cœur Culturel & Commercial (`DST-MATONGE` / `DST-KALAMU`)** : Économie créative, studios, ngandas, marchés denses, ateliers mécaniques (`FAM-KABONGO`).
- **Colonne Vertébrale Industrielle (`DST-LIMETE`)** : Usines, dépôts logistiques, carrefour monumental de la Tour de l'Échangeur (`LOC-LIMETE-ECHANGEUR`).
- **Flancs Fluviaux Occidentaux (`DST-NGALIEMA`)** : Relief prononcé, rapides de Kinsuka, carrières et zones résidentielles.
