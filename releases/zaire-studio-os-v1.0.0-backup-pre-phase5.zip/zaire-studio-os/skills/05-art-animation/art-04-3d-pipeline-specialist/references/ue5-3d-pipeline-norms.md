# Normes Géométriques, UV & Nomenclature UE5 (`ART-04`)

## 1. Convention de Nommage Officielle ZAÏRE STUDIO OS
- `SM_[Kit/District]_[AssetName]_[Variant]` (ex: `SM_Port_HangarWall_400a`)
- `SK_[Category]_[CharacterName]` (ex: `SK_Hero_Koffi`, `SK_Veh_MotoWewa01`)
- `T_[AssetName]_[D|N|ORM]` (`_D` = BaseColor sRGB, `_N` = Normal BC5 Linear, `_ORM` = Occlusion/Roughness/Metallic Linear)

## 2. Contraintes Techniques Nanite & Textures
- **Texel Density** : `10.24 px/cm` (0-3m), `5.12 px/cm` (3-15m), `1.28 px/cm` (HLOD).
- **Taille Max Texture** : `2048 × 2048` en standard environnement ; `4096 × 4096` réservé aux visages héros LOD 0 et trim sheets maîtresses.
- **WPO Cull Distance** : `<= 3500 cm` (`35 m`) obligatoire sur tout matériau utilisant World Position Offset.
