# Photométrie Équatoriale (Kinshasa 4°S) & Budgets Lumen (`ART-07`)

## 1. Matrice Photométrique de Référence (PBR Physical Units)
| État Horaire / Météo | Directional Light (Lux) | Température (K) | Sky Light / Rayleigh | Cible EV100 | Budget GPU Lumen |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Aube Fluviale (06h15)** | `18 000 Lux` | `3800 K` (Ambre doux) | Brume Exponential Height Fog dense | `11.8` | `<= 4.2 ms` |
| **Zénith Équatorial (12h30)** | `110 000 Lux` | `5600 K` (Blanc pur) | Ombres verticales très franches | `15.0` | `<= 4.0 ms` |
| **Orage (`TropicalStorm`)** | `9 500 Lux` | `7000 K` (Ardoise froid) | Nuages volumétriques bas + éclairs | `11.0` | `<= 4.5 ms` |
| **Nuit Matonge (21h30)** | `0.25 Lux` (Lune) | `4200 K` + Néons `2200-3200K` | Réflexions Lumen sur bitume humide | `3.5` | `<= 4.5 ms` |
