# Spécification de Kit Architectural & Matériaux PBR (`ART-02`)

- **ID Kit** : `KIT-[DST/LOC]-[SLUG]`
- **Brief Source (`WLD-06`)** : `ENV-...`
- **Texel Density** : `10.24 px/cm` (RDC) / `5.12 px/cm` (Étages)
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Inventaire des Modules Géométriques Nanite
| Nom Static Mesh | Dimensions (L × l × H cm) | Pivot | Nanite | Collision Simple |
| :--- | :--- | :--- | :--- | :--- |
| `SM_Kit_...` | `400 × 30 × 400` | `Coin Inf-Gauche` | `Oui` | `Box exacte BLK` |

## 2. Bibliothèque de Matériaux PBR & RVT
| ID Matériau | BaseColor (sRGB min-max) | Roughness | Packing Texture | Blend RVT Sol |
| :--- | :--- | :--- | :--- | :--- |
| `MI_...` | `[45 - 210]` | `[0.35 - 0.85]` | `BC7 + ORM` | `Oui (50 cm)` |
