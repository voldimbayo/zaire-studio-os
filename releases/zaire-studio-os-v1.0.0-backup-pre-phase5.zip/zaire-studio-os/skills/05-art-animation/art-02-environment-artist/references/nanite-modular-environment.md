# Production Environnementale Modulaire Nanite & RVT (`ART-02`)

## 1. Standards de Kits Modulaires Kinois
- **Grille de Snapping** : `100 cm`, `200 cm`, `400 cm` (hauteur d'étage standard = `400 cm` RDC commercial, `350 cm` étages).
- **Texel Density** : `10.24 px/cm` (0 à 3 m) -> `2048 × 2048` couvre exactement `200 × 200 cm`.
- **Channel Packing Obligatoire (`ORM`)** :
  - Canal **R** = Ambient Occlusion
  - Canal **G** = Roughness
  - Canal **B** = Metallic
  (Compression UE5 : `Masks (no sRGB)`, BC7/BC5 pour les normales).
