# Spécification Master Material & Contrôle PSO (`ART-08`)

- **Nom Master Material** : `M_Zaire_...`
- **Domaine** : `[Environment / Character / Vehicle / Water]`
- **Shading Model / Blend Mode** : `[Default Lit / Subsurface Profile | Opaque / Masked]`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Budget Instructions & Permutations PSO
- **Instructions Pixel Shader / Vertex Shader** : `[XXX / XXX]`
- **Texture Samplers Utilisés** : `[<= 6 via Shared:Wrap]`
- **Static Switches Autorisés (`<= 3`)** : `[Liste -> Total permutations = 2^N]`

## 2. Mapping Custom Primitive Data (Zéro PSO Supplémentaire)
| Index Float | Nom Paramètre | Plage Valeurs | Effet Visuel Dynamique |
| :--- | :--- | :--- | :--- |
| `Data[0]` | `TintHueShift` | `[0.0 - 1.0]` | `[Variation sans nouvelle instance]` |
