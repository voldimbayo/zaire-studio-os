# Gouvernance des Master Materials, PSO & Rigging (`ART-08`)

## 1. Catalogue des 8 Master Materials Officiels ZAÏRE
| Master Material | Domaine | Max Instructions PS | Max Static Switches | Custom Primitive Data |
| :--- | :--- | :--- | :--- | :--- |
| `M_Zaire_Env_Standard` | Architecture & Props Nanite | `<= 135` | `2` (RVT Blend, Triplanar) | `[0-3]` Tint RGB + Wetness |
| `M_Zaire_Env_Decal` | Signalétique, flaques, graffitis | `<= 95` | `1` | `[0]` Opacity / Wear |
| `M_Zaire_Foliage_Masked` | Végétation tropicale (WPO `<= 35m`) | `<= 140` | `1` | `[0]` Phase vent |
| `M_Zaire_Char_Skin` | Peau humaine Dual-Specular SSS | `<= 215` | `1` | `[0]` Sweat / Rain factor |
| `M_Zaire_Char_Cloth` | Vêtements wax / streetwear / cuir | `<= 150` | `2` | `[0-3]` Pattern Index + Tint |
| `M_Zaire_Hair_Cards` | Coiffures africaines Hair Cards | `<= 165` | `0` | `[0-2]` Melanin / Roughness |
| `M_Zaire_Vehicle_Master` | Carrosseries Wewa, Taxis, Bus | `<= 155` | `1` | `[0-4]` Couleur + Boue latérite |
| `M_Zaire_Water_River` | Fleuve Congo & Bassins portuaires | `<= 190` | `1` | Courant & Turbidité limon |
