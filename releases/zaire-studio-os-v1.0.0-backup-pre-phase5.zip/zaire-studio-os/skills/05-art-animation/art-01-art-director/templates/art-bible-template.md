# Directive de Direction Artistique — Art Bible (`ART-01`)

- **Cible Visuelle** : `DST-...` | `LOC-...` | `CHR-...`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Palette Chromatique & Matériaux PBR
- **Dominante (60 %)** : `[Teinte & Matériau]`
- **Secondaire (30 %)** : `[Teinte & Matériau]`
- **Accent & Affordance Gameplay (10 %)** : `[Couleur réservée aux interactions WLD-05]`
- **Plage Albédo PBR (`30-240 sRGB`)** : `[Vérifiée]`

## 2. Règles de Lisibilité & Contraste
- **Séparation Silhouette Joueur / Décor** : `[Directive contraste]`
