# Charte Chromatique & PBR de Kinshasa (`ART-01`)

## 1. Palettes Officielles par Commune (`DST-*`)
| Commune | Dominante (60 %) | Secondaire (30 %) | Accent & Lumière (10 %) | Contraste & Humeur |
| :--- | :--- | :--- | :--- | :--- |
| `DST-GOMBE` | Béton Brut & Verre (`#7A8288`) | Acier Portuaire & Vert Fluvial (`#2F4F4F`) | LED Froide & Sangles Jaunes (`#F2C94C`) | Vertical, institutionnel, reflets humides. |
| `DST-MATONGE` | Ocre Latérite & Crépi Chaud (`#B85D3B`) | Turquoise & Enseignes Peintes (`#1B998B`) | Néons Ambre/Magenta (`#FF3366`, `#FF9F1C`) | Vibrante, polyphonique, nocturne électrique. |
| `DST-LIMETE` | Béton Monumental Patiné (`#6E6A66`) | Tôle Rouillée & Verdure (`#8C4A27`) | Sodium Industriel (`#FFB347`) | Massif, industriel, silhouettes sur ciel équatorial. |

## 2. Plage de Calibration PBR Obligatoire
- **BaseColor (Albédo sRGB)** : Interdiction de descendre sous `30 sRGB` (charbon/pneu = `35-45 sRGB`) ou de dépasser `240 sRGB` pour laisser travailler Lumen GI (`ART-07`).
