# Architecture UE5 Niagara GPU & Contrôle d'Overdraw (`ART-09`)

## 1. Répartition du Budget GPU VFX (`PERF-GPU-NIAGARA <= 1.5 ms`)
| Catégorie VFX | Budget GPU Max | Simulation | Culling Distance | Max Instances Simultanées |
| :--- | :--- | :--- | :--- | :--- |
| **Météo (`NS_Weather_TropicalRain`)** | `<= 0.65 ms` | GPU Compute + Distance Field | Attaché Caméra (`18 m`) | `1 (Global)` |
| **Véhicules (`NS_Veh_LateriteDust`)** | `<= 0.40 ms` | GPU Compute + Cutout 8-verts | `4500 cm (45 m)` | `4 véhicules max` |
| **Combat (`NS_Cmb_MacheteParrySparks`)** | `<= 0.25 ms` | GPU / CPU Burst léger | `2500 cm (25 m)` | `4 impacts max` |
| **Ambiance (`NS_Env_StreetSteam_Smoke`)** | `<= 0.20 ms` | GPU Compute | `3500 cm (35 m)` | `12 sources locales` |
