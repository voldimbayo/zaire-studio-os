# Spécification Système VFX Niagara (`ART-09`)

- **Nom Système Niagara** : `NS_[CAT]_[SLUG]`
- **Gameplay Tag Déclencheur** : `[World.Weather... / Ability.Melee...]`
- **Budget GPU Alloué** : `[<= X.XX ms]`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Architecture Émetteurs & Optimisation Overdraw
- **Mode de Simulation** : `GPU Compute` | `CPU Burst`
- **Collisions** : `Global Distance Field` | `Analytical Plane`
- **Cutout Geometry & Packing Texture** : `[8-verts Cutout / Texture RGBA]`
- **Distance de Culling & Max Instances (`UNiagaraEffectType`)** : `[XXXX cm | N instances]`
