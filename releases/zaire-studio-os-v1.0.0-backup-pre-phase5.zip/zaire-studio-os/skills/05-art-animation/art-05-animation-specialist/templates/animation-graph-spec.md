# Spécification Architecture d'Animation UE5 (`ART-05`)

- **Cible Squelette** : `SK_Zaire_Master_Humanoid` (`CHR-...` / `AI-01`)
- **Budget CPU Max (`PERF-CPU-ANIM`)** : `<= 1.8 ms`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Configuration Motion Matching & Motion Warping
- **Pose Search Channels** : `[Trajectory, Pose, Velocity]`
- **Cibles Motion Warping (`WLD-05`)** : `[Tags & fenêtres cm]`

## 2. Synchronisation Frame Data Combat (`GD-05`)
| Montage Asset | Gameplay Tag | Startup (`f`) | Active Hitbox (`ANS_`) | Recovery / Cancel (`f`) |
| :--- | :--- | :--- | :--- | :--- |
| `AM_...` | `Ability.Melee...` | `f01 - fXX` | `fXX - fYY` | `fYY - fZZ` |
