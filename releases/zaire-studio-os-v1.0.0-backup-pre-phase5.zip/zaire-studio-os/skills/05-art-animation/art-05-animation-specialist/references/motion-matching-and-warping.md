# Architecture UE5 Motion Matching, Motion Warping & URO (`ART-05`)

## 1. Seuils de Synchronisation Spatiale (`WLD-05` <-> `ART-05`)
| Action (`FGameplayTag`) | Hauteur Cible | Fenêtre Tolérance Motion Warping | Durée Animation |
| :--- | :--- | :--- | :--- |
| `Ability.Movement.Vault` (Franchissement bas) | `100 cm` | `90 cm à 110 cm` (Distance d'appel `<= 180 cm`) | `0.55 s (33 frames)` |
| `Ability.Movement.ClimbHigh` (Mur / Conteneur) | `220 - 240 cm` | `200 cm à 250 cm` | `1.10 s (66 frames)` |
| `Ability.Movement.LedgeGrab` (Saut d'accroche) | `280 cm` | `260 cm à 300 cm` | `0.85 s (51 frames)` |

## 2. Paliers d'Optimisation CPU (`PERF-CPU-ANIM <= 1.8 ms`)
- **0 à 15 m** : Tick `60 Hz`, Motion Matching complet + Control Rig Foot/Hand IK actif.
- **15 à 35 m** : Tick `30 Hz` (URO Skip 1 frame), IK désactivé.
- **35 à 80 m** : Tick `15 Hz` (URO Skip 3 frames), State Machine simplifiée.
- **> 80 m** : Vertex Animation Texture (VAT) sur Static Mesh (`AI-02`), `0.0 ms` CPU squelettique.
