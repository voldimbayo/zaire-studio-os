# Protocole Motion Capture, Praticables & Retargeting UE5 (`ART-06`)

## 1. Alignement Plateau Physique <-> Métriques UE5 (`spatial-metrics.md`)
Tout praticable utilisé sur le volume de capture doit reproduire au centimètre près les cotes moteur :
- **Module Couvert Bas / Vault** : Hauteur `100 cm`, profondeur `100 cm`.
- **Gabarit Moto Wewa (`VEH-MOTO-WEWA-01`)** : Hauteur de selle `78 cm`, largeur guidon `76 cm`, repose-pieds à `32 cm`.
- **Hauteur de Barre d'Accroche (Ledge Grab)** : `280 cm`.
