# Pipeline Personnages : Shaders de Peau & Modularité PNJ (`ART-03`)

## 1. Calibration PBR des Carnations Foncées sous Lumière Équatoriale
- **BaseColor (Albédo sRGB)** : Plage réaliste calibrée entre `42 sRGB` et `115 sRGB` (jamais de noir pur, saturation riche dans les sous-tons chauds/dorés/acajou).
- **Dual Specular Lobe (UE5 Skin Shading)** : Lobe primaire `Roughness = 0.28` (sébum naturel), Lobe secondaire `Roughness = 0.48` (micro-relief pores via Cavity Map).
- **Subsurface Profile** : Diffusion sub-cutanée ambre-rouge subtil sur les oreilles, narines et contours sous contre-jour solaire équatorial (`EV100 = 15`).

## 2. Budgets Géométriques & LOD Personnages
| Catégorie | LOD 0 (Triangles) | LOD 1 (Triangles) | LOD 2 (Triangles) | LOD 3 VAT Foule |
| :--- | :--- | :--- | :--- | :--- |
| **Héros (`CHR-PROTAG-KOFFI`)** | `85 000 tris` | `42 000 tris` | `18 000 tris` | N/A |
| **PNJ Actif (`AI-01` Garde)** | `35 000 tris` | `16 000 tris` | `7 500 tris` | `2 800 tris` |
| **Citoyen Foule (`AI-02`)** | `22 000 tris` (Hydraté) | `9 500 tris` | `3 200 tris (VAT)` | `1 400 tris (VAT)` |
