# Definition of Done (DoD) & Seuils Qualité Studio (`DIR-07`)

## 1. Les 6 Critères Obligatoires de la Definition of Done
1. **Format & Gabarit** : Livrable structuré exactement selon le fichier `templates/` du skill.
2. **Intégrité des IDs** : 100 % des identifiants (`CHR-*`, `LOC-*`, `MSN-*`, etc.) présents et valides dans `knowledge/entities-registry.csv`.
3. **Traçabilité** : Sources techniques (`SRC-*`) et culturelles citées ; incertitudes isolées en `RESEARCH_REQUIRED`.
4. **Périmètre Respecté** : Zéro empiètement sur un autre skill du DAG.
5. **Budgets & Standards** : Frametime `<= 16.6 ms` (60 FPS) / `<= 33.3 ms` (30 FPS), couloirs `>= 350 cm`, Texel Density `10.24 px/cm`, expansion UI `+35 %`, support Unicode lingala (`ɛ`, `ɔ`).
6. **Validation Croisée** : Signature des auditeurs (`NAR-06`, `ENG-07`, `PRD-04`, `PRD-06`).

## 2. Seuils Quantitatifs d'Acceptation QA
- **Couverture Tests Automatisés (`PRD-05`)** : `>= 80 %` des systèmes critiques (`SYS-*`).
- **Taux de Reproductibilité Bugs (`PRD-04`)** : `>= 90 %` (avec coordonnées World Partition, seed et état de quête).
- **Taux de Faux Positifs Gauntlet** : `< 2 %`.
