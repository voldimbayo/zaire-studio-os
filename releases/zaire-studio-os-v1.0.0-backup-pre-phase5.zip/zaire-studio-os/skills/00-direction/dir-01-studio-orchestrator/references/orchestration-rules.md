# Règles d'Orchestration & Tri Topologique (`DIR-01`)

## 1. Protocole en 6 Phases
1. **INTAKE** : Lecture de `knowledge/entities-registry.csv`. Vérification des préfixes (`CHR-`, `FAM-`, `ORG-`, `DST-`, `LOC-`, `MSN-`, `ITM-`, `VEH-`, `SYS-`).
2. **PLANNING** : Calcul des strates 0 à 5. Aucun skill de Strate $N$ ne peut s'exécuter avant la complétion de ses dépendances amont de Strate $< N$.
3. **DISPATCH** : Envoi de la `Task Envelope` JSON.
4. **HANDOFF** : Réception du `Handoff Packet` Markdown.
5. **GATEKEEPING** : Contrôle par `NAR-06` (Continuité), `ENG-07` (Performance), `PRD-04` (QA) et `PRD-06` (Accessibilité XAG).
6. **CONSOLIDATION** : Mise à jour de `knowledge/entities-registry.csv` via `PRD-03` et validation finale `DIR-06`/`DIR-07`.

## 2. Plafonds Techniques Impératifs à Injecter dans `constraints`
- `target_frametime_ms` : `16.6` (Mode Performance 60 FPS) ou `33.3` (Mode Qualité 30 FPS).
- `max_npc_active` : `24` acteurs `AI-01` (au-delà, utiliser `AI-02` Mass Crowd jusqu'à 600+ entités).
- `min_corridor_width_cm` : `350` cm.
