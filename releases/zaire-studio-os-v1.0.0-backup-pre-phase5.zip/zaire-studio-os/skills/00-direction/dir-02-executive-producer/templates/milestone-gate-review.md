# Décision de Jalon & Arbitrage de Scope (`DIR-02`)

- **Jalon Évalué** : `Vertical Slice` | `Alpha` | `Beta` | `Gold`
- **Décision Exécutive** : `GO` | `CONDITIONAL_GO` | `NO_GO`
- **Variation Charge / Budget** : `[+X % / -Y %]`

## 1. Arbitrage du Périmètre (Scope Matrix)
| ID Entité / Système | Priorité (`P0`/`P1`/`P2`) | Décision (`MAINTAIN` / `DEFER` / `DEPRECATE`) | Justification |
| :--- | :--- | :--- | :--- |
| `DST-...` | `P0` | `MAINTAIN` | Cœur du Vertical Slice |

## 2. Risques Critiques & Conditions de Passage
- **Conditions obligatoires avant clôture** : `[Liste]`
