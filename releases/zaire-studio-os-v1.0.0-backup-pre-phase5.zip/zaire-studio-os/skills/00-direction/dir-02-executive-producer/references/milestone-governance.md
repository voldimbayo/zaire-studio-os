# Gouvernance des Jalons AAA (`DIR-02`)

## 1. Grille des Jalons de Production ZAÏRE
- **Vertical Slice (VS)** : 1 quartier complet (`DST-GOMBE` -> `LOC-GOMBE-PORT` + `DST-MATONGE` -> `LOC-MATONGE-VICTOIRE`), 1 mission principale (`MSN-MAIN-001-ARRIVEE`), boucle complète combat/infiltration/conduite Wewa à 60 FPS (`<= 16.6 ms`).
- **Feature Complete (Alpha)** : 100 % des systèmes (`SYS-*`) et quêtes principales jouables de bout en bout en blockout/art intermédiaire.
- **Content Complete (Beta)** : 100 % des assets artistiques, doublages multilingues (`fr-CD`, `ln-CD`) et optimisation PSO/VRAM intégrés.
- **Gold Master** : 0 bug Sévérité A/B, conformité XAG validée par `DIR-07`.
