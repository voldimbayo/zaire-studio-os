# Revue de Direction Créative (`DIR-03`)

- **Livrable Audité** : `[ID / Fichier]`
- **Skill Émetteur** : `[NAR-* / WLD-* / ART-* / AUD-*]`
- **Verdict Créatif** : `APPROVED` | `REVISION_REQUIRED` | `VETO_CREATIVE`

## 1. Évaluation sur les 3 Piliers Créatifs
| Pilier | Score (/5) | Commentaire & Directives |
| :--- | :--- | :--- |
| 1. Kinshasa Vivante & Souveraine | `[X/5]` | `[Analyse]` |
| 2. Ingéniosité Urbaine & Vélocité | `[X/5]` | `[Analyse]` |
| 3. Tension Sociale & Ancrage Humain | `[X/5]` | `[Analyse]` |

## 2. Conformité Culturelle & Sensorielle
- **Authenticité linguistique / sociale (`WLD-02`)** : `[OK / À corriger]`
- **Directives d'ajustement** : `[Instructions précises]`
