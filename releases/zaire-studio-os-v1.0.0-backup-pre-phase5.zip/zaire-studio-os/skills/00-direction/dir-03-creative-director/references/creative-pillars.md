# Les 3 Piliers Créatifs de ZAÏRE (`DIR-03`)

1. **Pilier 1 — Kinshasa Vivante & Souveraine ("Mégapole Électrique")** :
   La ville n'est pas un simple décor statique mais un organisme vivant, sonore, dense et stratifié où chaque commune (`DST-GOMBE`, `DST-MATONGE`, `DST-LIMETE`, `DST-KALAMU`) possède son propre pouls architectural, social et musical.
2. **Pilier 2 — Ingéniosité Urbaine & Vélocité ("Flux & Débrouillardise")** :
   Le joueur triomphe par sa lecture de la ville : maîtrise des réseaux humains, parkour urbain fluide, pilotage nerveux des motos Wewa (`VEH-MOTO-WEWA-01`) et utilisation tactique de la foule et de la météo équatoriale.
3. **Pilier 3 — Tension Sociale &Ancrage Humain ("Du Port aux Ngandas")** :
   Chaque conflit mêle enjeux intimes familiaux (`FAM-KABONGO` vs `FAM-MUKENDI`) et luttes d'influence économiques sur le bassin du fleuve Congo, portés par des dialogues bilingues français/lingala crédibles.
