# Règles de Gouvernance du Registre Maître (`DIR-06`)

## 1. Convention Stricte des 9 Préfixes d'Identifiants
- `CHR-[ROLE]-[SLUG]` : Personnages (`CATEGORY = CHARACTER`, Owner `NAR-03`)
- `FAM-[NOM]` : Familles (`CATEGORY = FAMILY`, Owner `NAR-03`)
- `ORG-[TYPE]-[SLUG]` : Organisations (`CATEGORY = ORGANIZATION`, Owner `NAR-05`)
- `DST-[COMMUNE]` : Quartiers / Communes (`CATEGORY = DISTRICT`, Owner `WLD-01`)
- `LOC-[DST]-[SLUG]` : Lieux / POI (`CATEGORY = LOCATION`, Owner `WLD-04`)
- `MSN-[TYPE]-[NUM]-[SLUG]` : Missions / Quêtes (`CATEGORY = MISSION`, Owner `GD-02`)
- `ITM-[CAT]-[SLUG]` : Objets / Équipements (`CATEGORY = ITEM`, Owner `GD-01`/`GD-03`/`GD-05`)
- `VEH-[CAT]-[SLUG]` : Véhicules (`CATEGORY = VEHICLE`, Owner `GD-06`)
- `SYS-[DOMAINE]-[SLUG]` : Systèmes de Gameplay (`CATEGORY = SYSTEM`, Owner `GD-01`/`ENG-01`/`AI-*`)

## 2. Matrice d'Autorisation des Transitions de Statuts
- `RESEARCH_REQUIRED -> PROPOSED` : Skill propriétaire après fourniture de la recherche `WLD-02`/`WLD-03`/`ENG-*`.
- `PROPOSED -> CONFIRMED` : Signature conjointe obligatoire de `DIR-06` + `DIR-07` (+ Directeur de pôle concerné).
- `* -> BLOCKED` : `DIR-04`, `DIR-07`, `NAR-06`, `ENG-07`, `PRD-04`.
- `* -> DEPRECATED` : `DIR-02`, `DIR-03`, `DIR-06`.
