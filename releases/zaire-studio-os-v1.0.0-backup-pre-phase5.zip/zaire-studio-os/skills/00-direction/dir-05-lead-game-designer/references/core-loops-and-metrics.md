# Boucles de Gameplay & Règles d'Arbitrage Ludique (`DIR-05`)

## 1. Boucle Principale (Core Loop) de ZAÏRE
1. **Reconnaissance Urbaine (Minute-to-Minute)** : Explorer Kinshasa sans mini-carte invasive grâce aux landmarks (`SYS-WLD-LANDMARKS`), écouter les rumeurs dans les ngandas (`DST-MATONGE`) et observer les routines PNJ (`AI-04`).
2. **Action & Approche Tactique** : Aborder chaque objectif (`MSN-*`) via un spectre fluide entre **Infiltration Sociale/Urbaine** (`SYS-STEALTH`), **Combat Corps-à-Corps Nerveux** (`SYS-CMB-MELEE`) et **Exfiltration Véhiculaire** (`VEH-MOTO-WEWA-01`).
3. **Impact & Réputation Locale (Hour-to-Hour)** : Faire évoluer la réputation par commune (`SYS-WLD-REPUTATION`), débloquer des raccourcis, des informateurs et des améliorations mécaniques (`GD-03`/`GD-04`).

## 2. Règles Non-Négociables de Playtest Blockout
- **Latence d'input combat** : `< 100 ms`.
- **Attack Tokens (`GD-05`)** : Maximum 2 assaillants au corps-à-corps simultanés contre Koffi en difficulté standard.
- **Règle des 40 secondes (`WLD-04`)** : Un point d'intérêt ou micro-événement systémique toutes les 40 secondes de déplacement à pied.
