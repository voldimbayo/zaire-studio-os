# Garde-Fous Techniques Unreal Engine 5 (`DIR-04`)

## 1. Enveloppes Budgétaires Incompressibles (Kinshasa Open World)
- **Frametime Total P99** : `16.6 ms` (60 FPS) / `33.3 ms` (30 FPS).
- **Game Thread** : `<= 6.5 ms` (`AI-01` <= 2.5 ms, `AI-02/03` Mass <= 2.0 ms, `ENG-05` Chaos <= 1.5 ms).
- **GPU Passes** : `ART-07` Lumen GI + Reflections `<= 4.5 ms`, `ART-04` Nanite `<= 2.5 ms`, `ART-09` Niagara `<= 1.5 ms`.
- **VRAM** : `<= 6144 MB` en cible standard (pools stricts : Virtual Textures, Render Targets Lumen/VSM, Meshes Nanite).

## 2. Règles d'Architecture Obligatoires
1. **World Partition & Data Layers (`ENG-01`)** : Taille de cellule `12800 cm` (128 m), rayon de chargement adapté à la vitesse maximale des motos Wewa (`VEH-MOTO-WEWA-01`).
2. **Zéro Chargement Synchrone** : Usage exclusif de `FStreamableManager::RequestAsyncLoad` et `TSoftObjectPtr<T>`.
3. **PSO Precache** : Collecte obligatoire des Pipeline State Objects sur chaque build nocturne (`ENG-08`).
