# ADR-TECH-NNN : [Titre de la Décision d'Architecture UE5]

- **Statut** : `PROPOSED` | `CONFIRMED`
- **Autorité** : `DIR-04 (Technical Director)`
- **Sous-systèmes Impactés** : `[PERF-CPU-* / PERF-GPU-* / SYS-*]`

## 1. Problématique & Contrainte Budgétaire
`[Description de la contrainte technique et de l'enveloppe ms/MB]`

## 2. Architecture Retenue
`[Spécification précise UE5 / Houdini / Wwise]`

## 3. Seuils de Validation (`ENG-07` / `PRD-05`)
- **Budget CPU max** : `[X.X ms]`
- **Budget GPU max** : `[Y.Y ms]`
- **Budget VRAM max** : `[Z MB]`
