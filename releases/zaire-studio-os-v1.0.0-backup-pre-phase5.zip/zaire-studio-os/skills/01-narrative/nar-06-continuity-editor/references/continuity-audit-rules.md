# Protocole d'Audit de Continuité & Anti-Paradoxe (`NAR-06`)

## 1. Les 4 Axes de Vérification Canonique
1. **Intégrité d'Entité** : Tout `CHR-*`, `FAM-*`, `ORG-*`, `DST-*`, `LOC-*`, `MSN-*` cité existe dans `knowledge/entities-registry.csv` et n'est ni `DEPRECATED` ni `BLOCKED`.
2. **Cohérence d'État (State Continuity)** : Vérification des préconditions de quête (ex: `CHR-ALLY-AMINA` ne peut pas guider Koffi par radio si l'émetteur de `ORG-RADIO-KIN` est en panne dans la quête courante).
3. **Cohérence Spatiale & Temps de Trajet** : Un personnage ne peut pas se téléporter instantanément de `LOC-GOMBE-PORT` à `LOC-LIMETE-ECHANGEUR` au sein de la même scène.
4. **Cohérence Linguistique** : Respect des glyphes Unicode (`ɛ`, `ɔ`) et de la voix définie par `NAR-03`.
