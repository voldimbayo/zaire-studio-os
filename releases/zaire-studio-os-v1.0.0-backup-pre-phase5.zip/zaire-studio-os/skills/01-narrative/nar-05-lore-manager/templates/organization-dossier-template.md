# Dossier d'Organisation Canonique (`NAR-05`)

- **ID Registre** : `ORG-[TYPE]-[SLUG]`
- **Nom Officiel** : `[Nom de l'Organisation]`
- **Quartier Général** : `LOC-...` (`DST-...`)
- **Dirigeant(s)** : `[CHR-*]`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Mandat, Ressources & Influence Urbaine
- **Façade Publique** : `[Activité visible]`
- **Activité Réelle / Enjeu Ludique** : `[Rôle dans le conflit de ZAÏRE]`
- **Présence par Commune (`DST-*`)** : `[Répartition]`

## 2. Contenus Diégétiques Associés (Radio / Signalétique)
- **Flash Radio `ORG-RADIO-KIN`** : « `[Texte de 25 mots max]` »
- **Signalétique Environnementale (`ART-02`)** : `[Slogan / Panneau]`
