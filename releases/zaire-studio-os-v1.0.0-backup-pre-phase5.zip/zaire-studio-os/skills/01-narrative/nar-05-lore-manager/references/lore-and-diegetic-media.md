# Architecture du Lore & Médias Diégétiques (`NAR-05`)

## 1. Factions & Organisations Clés (`ORG-*`)
- `ORG-CARTEL-FLEUVE` (**Syndicat du Fleuve**) : Consortium paramilitaire et logistique contrôlé par `CHR-ANTAG-MUKENDI` à `DST-GOMBE` (`LOC-GOMBE-PORT`).
- `ORG-TRANSCO` (**Réseau de Transport Urbain**) : Opérateur des grands bus structurant les axes routiers majeurs (`VEH-BUS-TRANSCO-01`).
- `ORG-RADIO-KIN` (**Radio Lokole 104.5 FM**) : Voix culturelle et citoyenne émettant depuis `DST-MATONGE`, animée par `CHR-ALLY-AMINA`.

## 2. Catégories de Médias Diégétiques
1. **Bulletins Radio Réactifs (`AUD-03`)** : Flashs de 15 à 25 secondes diffusés entre deux morceaux de rumba après chaque mission.
2. **Signalétique & Enseignes Peintes (`WLD-06`/`ART-02`)** : Textes d'ateliers mécaniques, salons de coiffure, ngandas et consignes portuaires.
