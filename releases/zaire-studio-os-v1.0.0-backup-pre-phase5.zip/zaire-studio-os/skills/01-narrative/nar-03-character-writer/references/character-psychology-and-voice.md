# Méthodologie de Conception des Personnages Kinois (`NAR-03`)

## 1. Grille Socio-Linguistique de Kinshasa
- **Profil Élite Technocratique / Sécuritaire (`DST-GOMBE`, ex: `CHR-ANTAG-MUKENDI`)** : Syntaxe française froide, chirurgicale, usage rare mais tranchant du lingala d'autorité pour intimider.
- **Profil Artiste / Média Urbain (`DST-MATONGE`, ex: `CHR-ALLY-AMINA`)** : Débit vif, métaphores empruntées à la rumba et à la radio (`ORG-RADIO-KIN`), code-switching fluide et chaleureux.
- **Profil Artisan / Coursier de Terrain (`DST-KALAMU`, ex: `CHR-PROTAG-KOFFI`)** : Pragmatique, économe en mots sous pression, maîtrise des codes du port (`Libongo`) comme de la rue (`Wewa`).
