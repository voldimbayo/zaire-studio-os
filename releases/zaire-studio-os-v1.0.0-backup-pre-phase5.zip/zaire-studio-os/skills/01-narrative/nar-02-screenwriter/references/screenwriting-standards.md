# Standards Scénaristiques & Cinématiques Temps Réel (`NAR-02`)

## 1. Règles de Rythme (Pacing AAA)
- **Durée maximale d'une Cutscene UE5 Sequencer** : `90 secondes` (au-delà, basculer en dialogue interactif `NAR-04` ou en phase jouable).
- **Continuité Caméra (Méthode Naughty Dog `SRC-011`)** : Les transitions entre gameplay et cinématique s'effectuent en plan-séquence sans fondu au noir, en conservant le même rig d'éclairage Lumen.
- **Usage du Code-Switching** : Le lingala intervient naturellement sur les salutations (`Mbote`), les exclamations d'urgence (`Kɛbá!`, `Tɔ́kɛndɛ́`) et les termes culturels (`Libongo`, `Wewa`, `Mosolo`).
