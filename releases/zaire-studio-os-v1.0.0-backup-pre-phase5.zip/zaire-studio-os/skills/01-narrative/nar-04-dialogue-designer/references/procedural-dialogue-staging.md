# Mise en Scène Procédurale & Architecture de Barks (`NAR-04`)

## 1. Pipeline de Cadrage Automatique (Inspiré d'Ubisoft GDC 2019 `SRC-014`)
Chaque ligne de dialogue porte deux métadonnées exploitées par le système caméra UE5 :
- `emotion_tag` : Pilote l'animation procédurale faciale/gestuelle (`NEUTRAL`, `TENSE`, `ANGRY`, `WARM`, `URGENT`, `IRONIC`).
- `camera_framing` : Pilote la sélection de caméra virtuelle (`OTS_LEFT`, `OTS_RIGHT`, `CLOSE_UP`, `TWO_SHOT`, `WIDE_ESTABLISHING`).

## 2. Calibrage UI & Accessibilité (`PRD-06` / `AUD-04`)
- **Maximum 20 mots par noeud** (environ 110 caractères en français, laissant la marge de +35 % d'expansion multilingue sans troncature).
- **Préfixe Locuteur Obligatoire** : Exporté sous la forme `[KOFFI]` ou `[AMINA]` pour les sous-titres enrichis XAG.
