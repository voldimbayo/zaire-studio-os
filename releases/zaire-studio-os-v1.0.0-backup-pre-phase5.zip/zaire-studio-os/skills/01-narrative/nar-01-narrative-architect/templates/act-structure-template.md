# Architecture d'Acte Narratif (`NAR-01`)

- **Acte** : `ACTE-[I / II / III]`
- **Titre** : `[Titre dramatique]`
- **Communes Principales** : `[DST-*]`
- **Personnages Pivots** : `[CHR-*]`

## 1. Progression Dramatique & Alignement Gameplay
| Séquence | Objectif Dramatique | Mission Associée (`MSN-*`) | Système Gameplay Sollicité (`SYS-*`) |
| :--- | :--- | :--- | :--- |
| 1 | `[Introduction / Incident]` | `MSN-MAIN-...` | `SYS-...` |

## 2. Embranchements & Conséquences Monde Ouvert
| Point de Choix | Option A (Impact Monde) | Option B (Impact Monde) | Variable d'État Persistante |
| :--- | :--- | :--- | :--- |
| `[Pivot]` | `[Conséquence A]` | `[Conséquence B]` | `WorldState.Act...` |
