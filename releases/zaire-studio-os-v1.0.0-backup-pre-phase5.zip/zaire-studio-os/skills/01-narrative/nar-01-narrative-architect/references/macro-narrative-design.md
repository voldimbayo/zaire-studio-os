# Architecture Narrative Interactive en Monde Ouvert (`NAR-01`)

## 1. Structure en 3 Actes de ZAÏRE
- **Acte I — Les Courants du Fleuve (`DST-KALAMU` & `DST-GOMBE`)** : Koffi Kabongo (`CHR-PROTAG-KOFFI`) découvre la mainmise du Syndicat du Fleuve (`ORG-CARTEL-FLEUVE`, dirigé par `CHR-ANTAG-MUKENDI`) sur les docks d'ONATRA (`LOC-GOMBE-PORT`).
- **Acte II — La Fréquence de Matonge (`DST-MATONGE` & `DST-LIMETE`)** : Alliance avec Amina Nzuzi (`CHR-ALLY-AMINA`) et `ORG-RADIO-KIN` pour fédérer les coursiers Wewa et les artisans face au blocus logistique autour de `LOC-LIMETE-ECHANGEUR`.
- **Acte III — L'Orage Équatorial (`DST-GOMBE` & `DST-NGALIEMA`)** : Confrontation finale entre les réseaux citoyens et la dynastie `FAM-MUKENDI` lors de la grande crue de la saison des pluies.

## 2. Règle de Convergence "Diamond Pattern"
Les choix du joueur dans l'Acte II altèrent l'allié dominant et le niveau d'alerte de `DST-GOMBE` en Acte III sans dupliquer les 100 % de la carte ouverte.
