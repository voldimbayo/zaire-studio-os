# Architecture Wwise Interactive Music & Radio Lokole (`AUD-03`)

## 1. Matrice d'Activation des Stems par Gameplay Tag
| État Gameplay (`FGameplayTag`) | Stem 1 (Pulse) | Stem 2 (Percus Congolaises) | Stem 3 (Guitare Mi-Solo) | Stem 4 (Sébène / Cuivres) | Règle Transition |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Exploration Libre** | Muets (Priorité Radio/Ville) | Muet | Muet | Muet | Fondu `2.0 s` |
| `State.Character.Stealth.Concealed` | **Actif (`0 dB`)** | Actif (`-6 dB`, filtré) | Muet | Muet | `Next Bar` |
| **Alerte / Poursuite Wewa** | **Actif (`0 dB`)** | **Actif (`0 dB`)** | **Actif (`0 dB`)** | Muet | `Next Beat` + Stinger |
| `State.Character.Combat.Engaged` | **Actif (`0 dB`)** | **Actif (`0 dB`)** | **Actif (`0 dB`)** | **Actif (`0 dB`)** | `Next Beat` + Impact |
