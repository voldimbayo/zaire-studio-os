# Design Sonore Systémique : RTPC, Surfaces & Spatial Audio (`AUD-02`)

## 1. Mapping `ChaosPhysicalMaterial` -> Switch Group Wwise `SW_Surface_Type`
- `PM_Asphalt_Dry` -> `SW_Surface_Asphalt_Dry`
- `PM_Asphalt_Wet` -> `SW_Surface_Asphalt_Wet` (ajoute la couche d'éclaboussure haute fréquence)
- `PM_Laterite_Dry` -> `SW_Surface_Laterite_Dry` (crissement granuleux de terre sèche)
- `PM_Laterite_Mud` -> `SW_Surface_Laterite_Mud` (succion visqueuse de boue tropicale)
- `PM_Corrugated_Iron` -> `SW_Surface_SheetMetal` (résonance métallique caractéristique des toits kinois sous l'averse)
