# Pipeline UE5 Localization Dashboard & Doublage (`AUD-04`)

## 1. Locales Supportées & Règles de Transcréation
- **`fr-CD` (Locale Native Maîtresse)** : Français de Kinshasa avec code-switching naturel en lingala (`LEX-001` à `LEX-012`).
- **`ln-CD` (Doublage & Sous-titres Lingala Complet)** : Version intégrale en lingala kinois utilisant l'alphabet Unicode normalisé (`a, e, ɛ, i, o, ɔ, u`).
- **`en-US` / `en-GB` (Internationalisation)** : Sous-titres et doublage anglais conservant les marqueurs identitaires (*Mbote*, *Wewa*, *Nganda*) accompagnés d'un contexte limpide.

## 2. Formule de Budget d'Expansion UI (`GD-07` <-> `AUD-04`)
$$\text{Capacité Conteneur UI (chars)} \ge \lceil \text{Longueur}(\text{Source}_{fr-CD}) \times 1.35 \rceil$$
