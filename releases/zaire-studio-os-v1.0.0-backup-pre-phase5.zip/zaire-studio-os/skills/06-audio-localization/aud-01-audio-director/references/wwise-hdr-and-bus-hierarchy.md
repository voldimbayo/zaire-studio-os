# Architecture Wwise HDR, Priorités de Mixage & Budgets (`AUD-01`)

## 1. Hiérarchie des Bus & Règles d'Atténuation (Ducking)
| Bus Wwise | Priorité | Cible LUFS | Ducking Appliqué sur Autres Bus | Stratégie Mémoire |
| :--- | :--- | :--- | :--- | :--- |
| `BUS_VO_Critical` | `100 (Max)` | `-20 LUFS` | `-6 dB` sur Musique & Ambiances, `-4.5 dB` sur Véhicules | Streamed + Prefetch `32 KB` |
| `BUS_SFX_CombatTelegraph` | `90` | `-18 LUFS Peak` | `-4 dB` sur Ambiances pendant Startup attaque `GD-05` | In-Memory (`Opus / ADPCM`) |
| `BUS_SFX_PlayerVehicle` | `75` | `-23 LUFS` | `-2 dB` sur Trafic IA distant | In-Memory (`Vorbis Q6`) |
| `BUS_Music_ScoreAndRadio` | `70` | `-24 LUFS` | Ducké par VO et Télégraphes Combat | Streamed + Prefetch `64 KB` |
| `BUS_Ambience_Kinshasa` | `50` | `-28 LUFS` | Ducké par tous les bus prioritaires | Streamed Multichannel |
