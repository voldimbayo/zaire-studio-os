# Spécification Audio Bible & Architecture Mixage (`AUD-01`)

- **Zone / Système** : `DST-...` | `SYS-...`
- **Budget RAM Audio Max** : `<= 512 MB`
- **Plafond Voix Physiques Wwise** : `<= 64 voix`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Signature Acoustique & Couches d'Ambiance
- **Fond Continu (Bed Quad/Ambisonic)** : `[Description]`
- **Ponctuels Spatialisés (3D One-Shots)** : `[Sources locales]`
- **Réverbération Spatiale (Wwise Late Reverb)** : `[RT60 & pré-délai]`

## 2. Règles de Mixage HDR & Ducking
- **Priorité Voix (`BUS_VO_Critical`)** : `[Règle d'atténuation]`
- **Signalétique Sonore Gameplay (`PRD-06` XAG)** : `[Indice audio distinctif]`
