# Simulation de Trafic Urbain sous UE5 ZoneGraph & MassTraffic (`AI-03`)

## 1. Comportements Spécifiques Kinois Modélisés
1. **Slalom Inter-File (`VEH-MOTO-WEWA-01`)** : Sous-voies virtuelles générées entre les voies principales de `350-400 cm`, offrant un couloir libre de `130-150 cm`.
2. **Arrêts Collectifs (`VEH-TAXI-JAUNE-01`)** : Déboîtement sur la bande d'arrêt latérale (`220 cm`) près des marchés pendant `6 à 12 secondes` pour déposer des passants `AI-02`.
3. **Priorité Anneau Circulaire (`LOC-MATONGE-VICTOIRE`)** : Priorité accordée aux véhicules engagés sur l'anneau intérieur pour évacuer le carrefour, avec cessions de passage dynamiques aux bus `VEH-BUS-TRANSCO-01`.
