# Spécification d'Architecture IA PNJ (`AI-01`)

- **ID Profil IA** : `AI-PRF-[SLUG]`
- **Archétypes Associés (`GD-05`)** : `[ENM-* / CHR-*]`
- **Plafond Acteurs Simultanés** : `[<= 24]`
- **Budget CPU Alloué** : `<= 2.5 ms`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Hiérarchie UE5 State Tree
| État State Tree | Condition d'Entrée (Tags / Perception) | Tâches & Smart Objects | Bark Associé (`NAR-04`) |
| :--- | :--- | :--- | :--- |
| `ST_Patrol` | `[Condition]` | `[Action]` | `BRK-...` |

## 2. Configuration des Requêtes EQS & Attack Tokens
- **Requête EQS Couverture / Flanquement** : `[Générateur, espacement cm, tests]`
- **Gestion des Attack Tokens (`GD-05`)** : `[Règle d'acquisition et de relâchement]`
