# Architecture UE5 State Trees, EQS & Perception (`AI-01`)

## 1. Budget & Plafonds d'Exécution (`PERF-CPU-NPCAI`)
- **Enveloppe CPU Max** : `2.5 ms` sur Game Thread / Worker Threads (`<= 24` acteurs `ACharacter` actifs).
- **Fréquence de Tick Perception** : `10 Hz` (`0.1 s`) pour les ennemis à `< 20 m` ; `4 Hz` (`0.25 s`) entre `20 m` et `60 m`.
- **Budget EQS** : Time-slicing réglé à `0.35 ms/frame` max pour l'évaluation des points de couverture.

## 2. Modulation Sensorielle par Gameplay Tags
| Gameplay Tag Actif | Multiplicateur Cône Visuel | Multiplicateur Rayon Auditif | Comportement Garde |
| :--- | :--- | :--- | :--- |
| `State.Character.Stealth.Concealed` | `0.25x` | `1.00x` | Ignore le joueur sauf à distance `< 300 cm` en plein axe. |
| `State.Character.Stealth.Disguised` | `0.15x` (zone autorisée) | `1.00x` | Salue ou contrôle verbalement (`BRK-PORT-01`) sans alerte immédiate. |
| `World.Weather.TropicalStorm` | `0.70x` (pluie dense) | `0.60x` (masquage pluie) | Cherche un abri Smart Object sous les auvents si non alerté. |
