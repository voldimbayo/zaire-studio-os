# Architecture ECS UE5 Mass Crowd — Marchés de Kinshasa (`AI-02`)

## 1. Anneaux de Level of Detail (MassRepresentation)
| Anneau LOD | Distance Caméra | Représentation Visuelle (`ART-03`/`ART-05`) | Physique & Navigation | Coût CPU Unitaire |
| :--- | :--- | :--- | :--- | :--- |
| **LOD 0 (Hydraté)** | `0 à 25 m` | `ACharacter` complet + Barks `NAR-04` | Capsule Chaos + Smart Objects | `~0.095 ms` (Pool max 18-24) |
| **LOD 1 (Médian)** | `25 à 80 m` | `USkeletalMeshComponent` partagé (URO 30Hz) | `ZoneGraph` + Évitement RVO | `~0.0045 ms` |
| **LOD 2 (Lointain)** | `80 à 250 m` | `UInstancedStaticMesh` + Vertex Anim Texture (VAT) | `ZoneGraph` cinématique pur | `~0.0018 ms` |
| **LOD 3 (Offscreen)** | `> 250 m` | Culled (0 draw call) | Progression statistique basse fréq. | `< 0.0003 ms` |
