# Catalogue d'Événements Systémiques & Utility AI (`AI-04`)

- **Commune Cible** : `DST-...`
- **Rayon d'Exclusion Mission Principale** : `80 mètres`
- **Plafond Acteurs Hydratés par Événement** : `<= 4 acteurs AI-01`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Table de Pondération Utility AI
| ID Événement | Commune (`World.District.*`) | Fenêtre Horaire | Météo Compatible | Cooldown (min) | Acteurs Hydratés |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `EVT-SYS-...` | `World.District...` | `[HH:MM-HH:MM]` | `[Sec / Pluie]` | `15 min` | `[2-4]` |

## 2. Déroulé Systémique & Récompense Émergente
- **Mise en situation** : `[Description]`
- **Interaction Joueur Optionnelle** : `[Action possible]`
- **Impact `SYS-WLD-REPUTATION` / Économie (`GD-03`)** : `[Gain]`
