# Modèle Utility AI & Événements Systémiques Urbains (`AI-04`)

## 1. Équation de Sélection d'Événement Systémique
Le directeur systémique évalue toutes les 10 secondes les ancres disponibles (`SmartObject` de trottoir à `40 - 90 m` en avant du joueur) selon :
$$U(E) = W_{\text{district}} \cdot W_{\text{time}} \cdot W_{\text{weather}} \cdot W_{\text{cooldown}}$$
L'événement ayant le score $U(E) > 0.65$ le plus élevé est instancié en hydratant 2 à 4 entités `AI-02` vers `AI-01`.
