# Modèle Mathématique Sources & Puits (`GD-03`)

## 1. Équation d'Équilibre Monétaire (`Mosolo`)
Pour chaque heure de jeu $t \in [1, 40]$, le flux net $\Delta M(t) = F(t) - S(t)$ doit vérifier :
$$0.75 \le \frac{S(t)}{F(t)} \le 0.92$$
- **Faucets $F(t)$** : $12\,000 + 2\,500 \cdot t$ (Missions principales, courses urgentes `MSN-SIDE-014-WEWA`, contrats d'atelier).
- **Sinks $S(t)$** : $9\,500 + 2\,150 \cdot t$ (Pièces moteur Wewa, outils d'infiltration, corruption/accréditations portuaires, équipement de mêlée).
