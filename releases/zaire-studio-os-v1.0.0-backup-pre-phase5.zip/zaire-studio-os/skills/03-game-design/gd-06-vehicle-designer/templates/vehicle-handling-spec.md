# Spécification de Conduite & Tuning Véhicule (`GD-06`)

- **ID Véhicule** : `VEH-[CAT]-[SLUG]`
- **Gameplay Tag** : `Vehicle.Type.[Nom]`
- **Gabarit (L × l × H en cm)** : `[XXX × XXX × XXX cm]`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Paramètres Dynamiques Chaos Vehicles (`ENG-05`)
- **Masse Totale (kg)** : `[XXXX kg]`
- **Centre de Gravité (Offset Z cm)** : `[-XX cm]`
- **Vitesse Max & Accélération (0-60 km/h)** : `[XX km/h | X.X s]`
- **Assistance & Stabilisation** : `[Règles gyroscopiques / anti-retournement]`

## 2. Réponse par Surface & Météo
| Surface (`ChaosPhysicalMaterial`) | Multiplicateur Grip Latéral | Multiplicateur Freinage | Effet Caméra / Audio (`AUD-02`) |
| :--- | :--- | :--- | :--- |
| `PM_Asphalt_Dry` | `1.20` | `1.15` | `[Effet]` |
