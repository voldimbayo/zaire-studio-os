# Paramétrage Simcade des Véhicules Kinois sous UE5 Chaos (`GD-06`)

## 1. Profils Physiques de Référence
| ID Véhicule | Masse (kg) | Gabarit L × l × H (cm) | Vitesse Max (km/h) | 0-60 km/h (s) | Rayon Braquage (m) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `VEH-MOTO-WEWA-01` | `135 kg` (210 avec pilote) | `205 × 80 × 115` | `95 km/h` | `3.2 s` | `2.4 m` |
| `VEH-TAXI-JAUNE-01` | `1 180 kg` | `440 × 180 × 150` | `125 km/h` | `5.8 s` | `5.1 m` |
| `VEH-BUS-TRANSCO-01` | `11 500 kg` | `1200 × 255 × 330` | `80 km/h` | `12.5 s` | `10.8 m` |

## 2. Matrice de Friction par Surface (`ChaosPhysicalMaterial`)
- `PM_Asphalt_Dry` : Friction Latérale = `1.20`, Friction Longitudinale = `1.15`.
- `PM_Asphalt_Wet` (`World.Weather.TropicalStorm`) : Friction Latérale = `0.90`, Longitudinale = `0.88`.
- `PM_Laterite_Dry` (`DST-KALAMU`) : Friction Latérale = `0.95`, Longitudinale = `0.92`.
- `PM_Laterite_Mud` (`World.Weather.TropicalStorm`) : Friction Latérale = `0.78`, Longitudinale = `0.75`.
