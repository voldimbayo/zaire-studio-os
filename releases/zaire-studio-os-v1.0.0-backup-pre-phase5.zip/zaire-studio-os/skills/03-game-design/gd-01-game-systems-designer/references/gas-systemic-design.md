# Conception Systémique Orientée UE5 GAS (`GD-01`)

## 1. Mapping Standard vers Gameplay Ability System
- **Activation Owned Tags** : Tags octroyés à l'acteur pendant que le système est actif (ex: `State.Character.Stealth.Disguised`).
- **Activation Blocked Tags** : Tags interdisant l'activation (ex: `State.Character.Combat.Engaged` bloque immédiatement l'accréditation sociale `ITM-DOC-PASSEPORT`).
- **Émergence Systémique** : L'averse équatoriale (`World.Weather.TropicalStorm`) atténue de `-40 %` le rayon de perception auditive des gardes (`AI-01`) tout en dispersant la foule civile (`AI-02`).
