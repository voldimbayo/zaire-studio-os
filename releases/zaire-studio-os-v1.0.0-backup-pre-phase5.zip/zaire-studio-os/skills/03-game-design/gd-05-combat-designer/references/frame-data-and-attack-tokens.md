# Frame Data (60 FPS) & Régulation par Attack Tokens (`GD-05`)

## 1. Standards de Frame Data à 60 FPS (`1 frame = 16.66 ms`)
| Action (`FGameplayTag`) | Startup (Frames) | Active (Frames) | Recovery (Frames) | Hitstop (ms) | Cancel Window |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `Ability.Melee.LightAttack` (Mains nues) | `9 f (150 ms)` | `4 f (66 ms)` | `11 f (183 ms)` | `40 ms` | Frame 16 -> Parade/Esquive |
| `Ability.Melee.LightAttack` (`ITM-WPN-MACHETTE`) | `12 f (200 ms)` | `5 f (83 ms)` | `14 f (233 ms)` | `55 ms` | Frame 20 -> Parade/Esquive |
| `Ability.Melee.HeavyAttack` (`ITM-WPN-MACHETTE`) | `24 f (400 ms)` | `6 f (100 ms)` | `20 f (333 ms)` | `90 ms` | Non annulable pendant Active |
| `State.Character.Combat.Parrying` | `3 f (50 ms)` | `12 f (200 ms)` | `10 f (166 ms)` | `85 ms` | Contre-attaque immédiate sur succès |
