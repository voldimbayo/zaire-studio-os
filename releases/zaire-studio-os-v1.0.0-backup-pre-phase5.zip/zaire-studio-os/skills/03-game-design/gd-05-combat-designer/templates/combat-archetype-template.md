# Spécification Combat & Archétypes Ennemis (`GD-05`)

- **Système** : `SYS-CMB-MELEE`
- **Arme / Capacité Évaluée** : `ITM-...` (`Ability.Melee...`)
- **Plafond Attack Tokens Escouade** : `2 jetons simultanés max`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Table Frame Data (Base 60 FPS)
| Mouvement | Gameplay Tag | Startup (f) | Active (f) | Recovery (f) | Dégâts | Hitstop (ms) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `[Nom coup]` | `Ability.Melee...` | `[XX]` | `[XX]` | `[XX]` | `[XX]` | `[XX ms]` |

## 2. Archétypes Ennemis & Comportement IA (`AI-01`)
| ID Archétype | Coût Attack Token | Santé (HP) | Pattern d'Attaque & Télégraphe | Contre Tactique Joueur |
| :--- | :--- | :--- | :--- | :--- |
| `ENM-...` | `1` | `[HP]` | `[Startup >= 22f + signal]` | `[Parade / Esquive]` |
