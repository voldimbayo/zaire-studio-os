# Mission Design Document (`GD-02`)

- **ID Mission** : `MSN-[MAIN/SIDE]-[NUM]-[SLUG]`
- **Titre** : `[Titre de la Mission]`
- **Lieu & Commune** : `LOC-...` (`DST-...`)
- **Plafond PNJ `AI-01` Actifs** : `[<= 24]`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Approches Tactiques Multiples
- **Approche A (Infiltration / Social `SYS-STEALTH`)** : `[Mécanique]`
- **Approche B (Mêlée / Action `SYS-CMB-MELEE`)** : `[Mécanique]`
- **Approche C (Mobilité / Exfiltration `VEH-*`)** : `[Mécanique]`

## 2. Machine à États & Protection Anti-Soft-Lock
| Étape ID | Objectif Joueur | Condition Transition Succès | Handler Anti-Soft-Lock (Véhicule détruit / Fuite / Alerte) |
| :--- | :--- | :--- | :--- |
| `ST-01` | `[Objectif]` | `[Condition]` | `[Action de récupération sans blocage]` |
