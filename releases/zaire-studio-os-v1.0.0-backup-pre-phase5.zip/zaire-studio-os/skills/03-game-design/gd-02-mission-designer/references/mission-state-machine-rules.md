# Architecture de Quêtes Tolérantes aux Interruptions (`GD-02`)

## 1. Protocole Anti-Soft-Lock en Monde Ouvert
Dans un monde ouvert systémique comme Kinshasa, toute étape de mission doit survivre à 4 événements imprévus :
1. `EVENT_VEHICLE_LOST` : Destruction ou perte de `VEH-MOTO-WEWA-01` -> activation d'un point de récupération secondaire ou continuation en parkour.
2. `EVENT_STEALTH_BROKEN` : Échec de l'infiltration `SYS-STEALTH` -> transition dynamique de l'objectif "Infiltrer sans alerte" vers "Arracher les registres sous le feu et s'exfiltrer" (pas d'écran d'échec punitif).
3. `EVENT_AREA_ABANDONED` : Sortie du rayon de `300 m` -> suspension propre de la mission au dernier checkpoint atomique.
4. `EVENT_WEATHER_SHIFT` : Déclenchement de `World.Weather.TropicalStorm` -> adaptation des cônes de détection `AI-01` et de l'adhérence `GD-06`.
