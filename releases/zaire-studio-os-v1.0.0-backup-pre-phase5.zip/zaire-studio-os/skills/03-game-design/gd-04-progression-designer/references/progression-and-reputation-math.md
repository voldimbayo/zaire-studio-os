# Formules de Progression & Réputation par Quartier (`GD-04`)

## 1. Courbe d'Expérience (Niveaux 1 à 20)
$$XP_{\text{requis}}(L) = 500 \cdot L^2 + 1500 \cdot L$$
- **Niveau 1 -> 5 (Acte I)** : Maîtrise des fondamentaux (contre-attaque machette, slalom Wewa, laissez-passer).
- **Niveau 6 -> 14 (Acte II)** : Synergies urbaines (appel d'attroupement via `ORG-RADIO-KIN`, sabotage de grues/transformateurs).
- **Niveau 15 -> 20 (Acte III)** : Maîtrise complète des 3 branches.
