# Spécification d'Arbre de Progression & Réputation (`GD-04`)

- **Système Lié** : `SYS-WLD-REPUTATION` & Progression `CHR-PROTAG-KOFFI`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Matrice des Compétences Déblocables (Mapping GAS)
| Skill Node ID | Branche | Gameplay Tag Associé | Prérequis | Effet Tactique Concret |
| :--- | :--- | :--- | :--- | :--- |
| `SKL-...` | `[Mêlée / Wewa / Réseau]` | `Ability....` | `[Niveau / Node]` | `[Description]` |

## 2. Paliers de Réputation par Commune (`DST-*`)
| Palier | Seuil Points | Effet sur la Foule (`AI-02`) & Commerces (`GD-03`) |
| :--- | :--- | :--- |
| 1. Inconnu | `0 - 249` | Comportement neutre, prix standards (`1.0x`). |
