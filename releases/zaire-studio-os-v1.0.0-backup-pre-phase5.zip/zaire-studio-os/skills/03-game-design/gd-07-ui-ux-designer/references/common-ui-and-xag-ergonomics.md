# Architecture UE5 Common UI & Ergonomie Accessible (`GD-07`)

## 1. Hiérarchie des Couches (`UCommonActivatableWidget` Stack)
- `UI.Layer.HUD` : Jauge d'endurance/santé contextuelle (masquée à 100 % hors combat), boussole discrète de landmarks (`SYS-WLD-LANDMARKS`), sous-titres enrichis.
- `UI.Layer.DiegeticPhone` : Téléphone portable de Koffi consultable en temps réel sans couper le monde (SMS d'Amina `CHR-ALLY-AMINA`, tuner `ORG-RADIO-KIN`, carte par commune `DST-*`).

## 2. Normes Typographiques & Accessibilité (`PRD-06` / `AUD-04`)
- **Glyphes Obligatoires** : Support natif de `ɛ`, `Ɛ`, `ɔ`, `Ɔ` et des diacritiques tonals (`á`, `é`, `ɛ́`, `ɔ́`).
- **Taille Minimale Police TV/Console (1080p réf)** : `24 px` pour le corps d'interface, `28 px` à `42 px` (réglable) pour les sous-titres avec préfixe locuteur `[KOFFI]` et fond noir opacité `60-85 %`.
- **Tolérance d'Expansion** : `+35 %` de longueur de chaîne sur tous les boutons, notifications et objectifs.
