# Optimisation Bas Niveau du Pipeline Graphique UE5 (`ENG-06`)

## 1. Matrice des CVar de Référence (Mode Performance 60 FPS vs Mode Qualité 30 FPS)
| Sous-Système / CVar UE5 | Mode Performance (60 FPS / `<= 16.6 ms`) | Mode Qualité (30 FPS / `<= 33.3 ms`) | Impact GPU |
| :--- | :--- | :--- | :--- |
| **Résolution Interne -> TSR Output** | `1080p..1440p -> 4K TSR` | `1440p..1800p -> 4K TSR` | Gain `-3.2 ms` |
| `r.Lumen.HardwareRayTracing` | `0 (Software SDF + Surface Cache)` | `1 (Hardware RT Reflections)` | Gain `-2.4 ms` |
| `r.Lumen.Reflections.MaxRoughnessToTrace` | `0.40` (Au-delà : Surface Cache) | `0.55` | Gain `-0.8 ms` |
| `r.Shadow.Virtual.ResolutionLodBiasDirectional` | `-0.5` | `-1.0` | Gain `-0.7 ms` |
| **WPO Shadow Invalidation Distance** | `2500 cm (25 m)` | `3500 cm (35 m)` | Préserve le cache VSM |
