# Spécification Pipeline de Rendu & Scalabilité (`ENG-06`)

- **Passe Graphique / Feature** : `[Lumen / Nanite / VSM / Water / TSR]`
- **Budget GPU Mode Perf (60 FPS)** : `[<= X.X ms]`
- **Budget GPU Mode Qualité (30 FPS)** : `[<= Y.Y ms]`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Configuration des Passes RHI & CVar (`DefaultEngine.ini` / `Scalability.ini`)
| CVar / Paramètre | Valeur Perf (60 FPS) | Valeur Qualité (30 FPS) | Justification Technique |
| :--- | :--- | :--- | :--- |
| `r.Lumen...` | `[Val]` | `[Val]` | `[Impact RenderDoc]` |

## 2. Contrôles de Stabilité Temporelle & Cache VSM
- **Taux de Cache VSM Cible** : `[>= 92 %]`
- **Gestion Anti-Ghosting TSR** : `[Paramètre]`
