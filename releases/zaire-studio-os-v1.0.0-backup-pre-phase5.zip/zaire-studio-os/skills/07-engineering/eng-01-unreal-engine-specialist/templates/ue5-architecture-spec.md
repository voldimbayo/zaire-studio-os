# Spécification d'Architecture C++20 Unreal Engine 5 (`ENG-01`)

- **Module / Subsystem** : `ZaireCore` | `UZaire...Subsystem`
- **Système Associé** : `SYS-...`
- **Budget Game Thread (`PERF-CPU-GAME`)** : `<= 6.5 ms`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Architecture des Classes C++ & Dépendances Modules
- **Classe Principale** : `U...` (Héritage, cycle de vie)
- **Gestion Mémoire & Streaming** : `[TSoftObjectPtr / FStreamableManager]`

## 2. Configuration World Partition & Data Layers
| Data Layer | Type (`Runtime` / `Editor`) | Condition d'Activation | Budget VRAM |
| :--- | :--- | :--- | :--- |
| `DL_...` | `Runtime` | `[Gameplay Tag / État Quête]` | `[XX MB]` |
