# Architecture C++20 UE5 : World Partition & Streaming Asynchrone (`ENG-01`)

## 1. Configuration des Grilles World Partition (`SYS-WLD-STREAMING`)
| Nom Grille | Taille Cellule (cm) | Rayon Chargement (cm) | Contenu Cible | Stratégie HLOD |
| :--- | :--- | :--- | :--- | :--- |
| `MainGrid_Kinshasa` | `12800 cm (128 m)` | `25600 cm (256 m)` | Architecture modulaire (`ART-02`), Couverts, Routes | `HLOD0_Instanced` -> `HLOD1_MergedMesh` |
| `PropsAndInteriorGrid` | `6400 cm (64 m)` | `12800 cm (128 m)` | Props intérieurs, étals de marché, petits débris | Culled hors rayon (Pas de HLOD) |
| `LandmarkMacroGrid` | `51200 cm (512 m)` | `153600 cm (1.53 km)` | `LOC-LIMETE-ECHANGEUR`, Grues `LOC-GOMBE-PORT` | `HLOD_AlwaysLoaded_LowPoly` |

## 2. Pattern C++20 Obligatoire de Chargement Asynchrone
```cpp
void UZaireStreamingSubsystem::RequestDistrictAssets(const TArray<FSoftObjectPath>& AssetsToLoad, FSimpleDelegate OnLoaded)
{
    FStreamableManager& Streamable = UAssetManager::GetStreamableManager();
    ActiveHandle = Streamable.RequestAsyncLoad(AssetsToLoad, MoveTemp(OnLoaded), FStreamableManager::DefaultAsyncLoadPriority);
}
```
