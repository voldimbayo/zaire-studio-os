# Spécification Pipeline CI/CD BuildGraph & Packaging (`ENG-08`)

- **Nom du Pipeline** : `BG_Zaire_...`
- **Cible Temps Build Incrémental (`PERF-CI-BUILD`)** : `<= 15.0 minutes`
- **Taux de Cache Hit Zen DDC Requis** : `>= 95 %`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Étapes du Graphe BuildGraph / Horde
| Étape | Commande UAT / Commandlet | Timeout (min) | Condition d'Échec Bloquant |
| :--- | :--- | :--- | :--- |
| `1_Validate` | `RunUnreal -Commandlet=DataValidation` | `3 min` | `> 0 asset invalide (ENG-03)` |

## 2. Sécurité Packaging IoStore & Gestion des Secrets
- **Chiffrement Index `.utoc`** : `AES-256 via Variable d'Environnement (Zéro clé en dur)`
- **Overhead CPU Décompression** : `[< 0.5 %]`
