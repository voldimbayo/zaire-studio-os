# Architecture CI/CD BuildGraph, Zen DDC & Sécurité IoStore (`ENG-08`)

## 1. Pipeline CI/CD en 5 Étapes (Budget Incrémental `<= 15 min`)
1. **Pre-Flight & Secret Scan (`< 30 s`)** : Vérifie l'absence de secrets en dur, exécute `tools/validate_registry.py`, `tools/check_dag_cycles.py` et `tools/lint_skills.py`.
2. **Compile C++20 via UnrealBuildAccelerator (UBA) (`<= 4 min`)** : Compilation distribuée avec `/W4` et `IWYU`.
3. **Asset Validation (`ENG-03`, `<= 2 min`)** : Exécution headless du commandlet `ValidateAssets`.
4. **Incremental Cook & IoStore Package via Zen DDC (`<= 7 min`)** : Génération des conteneurs `.utoc`/`.ucas`/`.pak` avec injection de `$ENV{ZAIRE_PAK_AES256_KEY}`.
5. **Automated Gauntlet & PSO Merge (`PRD-05` / `ENG-07`)** : Exécution des tests rapides de fumée (Smoke Tests) et consolidation du cache `.upipelinecache`.
