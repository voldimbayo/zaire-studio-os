# Spécification Simulation Physique Chaos (`ENG-05`)

- **Système** : `SYS-PHYS-CHAOS`
- **Cible Physique** : `[VEH-* / Props Destructibles / Ragdoll]`
- **Budget CPU Max (`PERF-CPU-CHAOS`)** : `<= 1.5 ms`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Paramètres du Solveur Chaos & Async Tick
- **Fréquence Async Tick** : `60 Hz (16.66 ms pas fixe)`
- **Iterations Solveur (Position / Velocity)** : `[8 / 2]`
- **Seuils de Mise en Sommeil (Linear / Angular Sleep)** : `[Valeurs]`

## 2. Règles de Collision & Destruction (`Geometry Collection`)
- **Primitives autorisées** : `[Box / Sphere / Capsule / Convex <= 18]`
- **Politique de recyclage des débris** : `[Sleep <= 1.2s, Cull <= 4.0s]`
