# Architecture UE5 Chaos Physics & Matrice de Collisions (`ENG-05`)

## 1. Matrice de Réponse des Profils de Collision (`SYS-PHYS-CHAOS`)
| Profil Collision | `WorldStatic` | `Pawn (Koffi/PNJ)` | `Vehicle (Wewa/Bus)` | `CombatHitbox` | `ChaosDebris` | `Camera` |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`WorldStatic`** | Ignore | **Block** | **Block** | Overlap | **Block** | **Block** |
| **`Pawn`** | **Block** | **Block** | **Block** | **Overlap** | Ignore | Ignore |
| **`Vehicle`** | **Block** | **Block** | **Block** | Overlap | **Block** (Impulse) | **Block** |
| **`ChaosDebris`** | **Block** | Ignore | Ignore (Post-break) | Ignore | **Ignore** | **Ignore** |
