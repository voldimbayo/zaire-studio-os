# Architecture C++ UE5 Gameplay Ability System & Enhanced Input (`ENG-02`)

## 1. Déclaration Native des Gameplay Tags (`ZaireGameplayTags.h`)
Tous les tags de `knowledge/technical-specs/gameplay-tags-taxonomy.csv` sont enregistrés en C++ natif :
```cpp
namespace ZaireGameplayTags
{
    UE_DECLARE_GAMEPLAY_TAG_EXTERN(State_Character_Combat_Engaged);
    UE_DECLARE_GAMEPLAY_TAG_EXTERN(State_Character_Combat_Parrying);
    UE_DECLARE_GAMEPLAY_TAG_EXTERN(State_Character_Stealth_Concealed);
    UE_DECLARE_GAMEPLAY_TAG_EXTERN(State_Character_Stealth_Disguised);
    UE_DECLARE_GAMEPLAY_TAG_EXTERN(Ability_Melee_LightAttack);
    UE_DECLARE_GAMEPLAY_TAG_EXTERN(Ability_Melee_HeavyAttack);
    UE_DECLARE_GAMEPLAY_TAG_EXTERN(Ability_Movement_Vault);
}
```
