# Pipeline Procédural Hybride : SideFX Houdini PDG -> UE5 PCG (`ENG-04`)

## 1. Répartition des Responsabilités Houdini (Offline PDG) vs UE5 PCG (In-Engine)
- **SideFX Houdini 20.5+ (HDA / PDG TOP Network)** :
  - Nettoyage topologique des graphes routiers OpenStreetMap et projection sur le MNT (DEM) du bassin du fleuve Congo.
  - Calcul géométrique lourd des carrefours complexes (`LOC-MATONGE-VICTOIRE`, bretelles de `LOC-LIMETE-ECHANGEUR`) et génération des profils `ZoneGraph`.
  - Subdivision des îlots urbains en lots orientés et export de **Point Clouds `.pcg` / Alembics légers** dotés d'attributs (`@kit_id`, `@floor_count`, `@district_tint`).
- **Unreal Engine 5 PCG Framework (Runtime / Editor Graphs)** :
  - Lecture des Point Clouds Houdini et instanciation directe des meshes Nanite (`ART-02`) avec injection de `CustomPrimitiveData`.
  - Adaptation dynamique locale aux volumes d'exclusion `WLD-05` et au matériau RVT du terrain.
