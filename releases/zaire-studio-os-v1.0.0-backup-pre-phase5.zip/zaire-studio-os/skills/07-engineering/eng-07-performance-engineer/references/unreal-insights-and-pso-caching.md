# Protocole de Profilage Unreal Insights & PSO Precaching (`ENG-07`)

## 1. Grille de Contrôle P99 Obligatoire (`knowledge/technical-specs/performance-budgets.csv`)
| ID Budget | Sous-Système | Plafond 60 FPS | Plafond 30 FPS | Skill Responsable |
| :--- | :--- | :--- | :--- | :--- |
| `PERF-TOTAL-FRAME` | Frametime Global P99 | `<= 16.6 ms` | `<= 33.3 ms` | `ENG-07` |
| `PERF-CPU-GAME` | Game Thread Total | `<= 6.5 ms` | `<= 12.0 ms` | `ENG-01` |
| `PERF-CPU-NPCAI` | NPC AI (`<= 24` acteurs) | `<= 2.5 ms` | `<= 3.0 ms` | `AI-01` |
| `PERF-CPU-MASS` | Mass Crowd & Traffic (`600+`) | `<= 2.0 ms` | `<= 2.5 ms` | `AI-02` / `AI-03` |
| `PERF-CPU-CHAOS` | Chaos Physics & Vehicles | `<= 1.5 ms` | `<= 2.0 ms` | `ENG-05` |
| `PERF-CPU-ANIM` | Animation & Motion Matching | `<= 1.8 ms` | `<= 2.5 ms` | `ART-05` |
| `PERF-GPU-LUMEN` | Lumen GI & Reflections | `<= 4.5 ms` | `<= 7.0 ms` | `ART-07` / `ENG-06` |
| `PERF-GPU-NANITE` | Nanite Raster & VisBuffer | `<= 2.5 ms` | `<= 4.0 ms` | `ART-04` / `ENG-06` |
| `PERF-GPU-NIAGARA` | Niagara VFX | `<= 1.5 ms` | `<= 2.0 ms` | `ART-09` |
| `PERF-MEM-VRAM` | VRAM Totale Allouée | `<= 6144 MB` | `<= 8192 MB` | `DIR-04` |
