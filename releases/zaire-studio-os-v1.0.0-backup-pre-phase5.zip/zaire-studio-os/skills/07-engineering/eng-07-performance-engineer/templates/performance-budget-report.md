# Rapport d'Audit de Performance & Budgets UE5 (`ENG-07`)

- **Parcours / Commune Testée** : `DST-...` (`LOC-...`)
- **Mode Cible** : `Mode Performance (60 FPS / <= 16.6 ms)`
- **Résultat `check_perf_budget.py`** : `PASS` | `FAIL (BLOCKED)`
- **Marge P99 (Headroom)** : `[+X.XX ms]`

## 1. Relevé détaillé par Sous-Système (Unreal Insights / RenderDoc)
| ID Budget | Plafond (ms/MB) | Mesuré P95 | Mesuré P99 | Statut (`OK` / `OVER_BUDGET`) |
| :--- | :--- | :--- | :--- | :--- |
| `PERF-TOTAL-FRAME` | `16.6 ms` | `[XX.X ms]` | `[XX.X ms]` | `OK` |

## 2. Statut PSO Precaching & Streaming
- **Hitches PSO (> 5 ms)** : `[0 détecté]`
- **Actions d'Optimisation Requises** : `[Aucune / Tickets assignés]`
