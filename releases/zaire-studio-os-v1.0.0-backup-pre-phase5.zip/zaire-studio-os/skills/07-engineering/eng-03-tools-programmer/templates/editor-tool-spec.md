# Spécification d'Outil Éditeur & Validateur UE5 (`ENG-03`)

- **Nom du Validateur / Outil** : `UZaire...Validator` | `EUW_Zaire_...`
- **Module Cible** : `ZaireEditor (Type: Editor)`
- **Règles Métier Appliquées** : `[ART-04 / ENG-01 / WLD-05]`
- **Statut** : `PROPOSED` | `CONFIRMED`

## 1. Logique de Validation & Auto-Fix
- **Condition d'Activation (`CanValidateAsset`)** : `[Classes UObject ciblées]`
- **Contrôles Exécutés (`ValidateLoadedAsset`)** : `[Règles déterministes]`
- **Action Auto-Fix Disponible** : `[Correction automatique proposée]`
