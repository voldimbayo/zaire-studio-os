# Architecture des Validateurs Pré-Commit UE5 (`ENG-03`)

## 1. Liste des Validateurs Automatisés (`UDataValidationSubsystem`)
1. `UZaireAssetNamingValidator` : Vérifie les préfixes `SM_`, `SK_`, `M_`, `MI_`, `T_`, `NS_`, `BP_`.
2. `UZaireNaniteAndMaterialValidator` : Interdit `BLEND_Translucent` sur Nanite et vérifie que `WPO Disable Distance <= 3500 cm`.
3. `UZaireTextureORMValidator` : Vérifie les dimensions puissances de 2 et force `sRGB = false` + `TC_Masks` sur le suffixe `_ORM`.
4. `UZaireHardReferenceValidator` : Scanne les Blueprints de quête/monde pour interdire les références dures vers des acteurs hors Data Layer courant.
