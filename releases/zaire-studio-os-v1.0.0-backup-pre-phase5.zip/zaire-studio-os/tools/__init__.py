"""Utilitaires partagés et parseur YAML/Frontmatter déterministe pour ZAÏRE STUDIO OS."""

from __future__ import annotations

from pathlib import Path
from typing import Any

WORKSPACE_ROOT = Path(__file__).resolve().parent.parent


class YamlParseError(ValueError):
    """Erreur levée lorsqu'un bloc YAML ou frontmatter SKILL.md est invalide."""


def resolve_safe_path(base_dir: Path, relative_target: str) -> Path:
    """Résout un chemin relatif en interdisant toute traversée hors de base_dir."""
    if not relative_target or "\x00" in relative_target:
        raise ValueError(f"Chemin cible invalide : {relative_target!r}")
    base_resolved = base_dir.resolve()
    candidate = (base_resolved / relative_target).resolve()
    try:
        candidate.relative_to(base_resolved)
    except ValueError as exc:
        raise ValueError(
            f"Violation de sécurité de chemin : {relative_target!r} sort de {base_resolved}"
        ) from exc
    return candidate


def _parse_scalar(raw_val: str) -> Any:
    """Convertit une valeur scalaire YAML en type Python natif."""
    val = raw_val.strip()
    if not val:
        return ""
    if (val.startswith('"') and val.endswith('"')) or (
        val.startswith("'") and val.endswith("'")
    ):
        return val[1:-1]
    if val.startswith("[") and val.endswith("]"):
        inner = val[1:-1].strip()
        if not inner:
            return []
        return [_parse_scalar(item) for item in inner.split(",")]
    lowered = val.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered in ("null", "none", "~"):
        return None
    if val.isdigit() or (val.startswith("-") and val[1:].isdigit()):
        return int(val)
    try:
        return float(val)
    except ValueError:
        return val


def parse_simple_yaml(yaml_text: str) -> dict[str, Any]:
    """Parse un sous-ensemble structuré de YAML (dictionnaires imbriqués, listes, scalaires).

    Conçu sans dépendance externe pour valider les frontmatters SKILL.md de manière
    strictement déterministe dans tous les environnements Python 3.10+.
    """
    lines = yaml_text.splitlines()
    root: dict[str, Any] = {}
    stack: list[tuple[int, dict[str, Any] | list[Any]]] = [(-1, root)]

    for line_num, raw_line in enumerate(lines, start=1):
        if "\t" in raw_line:
            raise YamlParseError(f"Ligne {line_num}: les tabulations sont interdites en YAML.")
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue

        indent = len(raw_line) - len(raw_line.lstrip(" "))
        while len(stack) > 1 and indent <= stack[-1][0]:
            stack.pop()

        parent = stack[-1][1]

        if stripped.startswith("- "):
            item_text = stripped[2:].strip()
            if not isinstance(parent, list):
                raise YamlParseError(
                    f"Ligne {line_num}: élément de liste inattendu hors d'un conteneur liste."
                )
            parent.append(_parse_scalar(item_text))
            continue

        if ":" not in stripped:
            raise YamlParseError(f"Ligne {line_num}: syntaxe clé:valeur attendue ({stripped!r}).")

        key_part, _, val_part = stripped.partition(":")
        key = key_part.strip()
        if not key:
            raise YamlParseError(f"Ligne {line_num}: clé YAML vide.")
        val_clean = val_part.strip()

        if not isinstance(parent, dict):
            raise YamlParseError(
                f"Ligne {line_num}: impossible d'affecter la clé {key!r} dans une liste."
            )

        if not val_clean:
            next_container: dict[str, Any] | list[Any] = {}
            for lookahead in lines[line_num:]:
                la_strip = lookahead.strip()
                if not la_strip or la_strip.startswith("#"):
                    continue
                la_indent = len(lookahead) - len(lookahead.lstrip(" "))
                if la_indent > indent and la_strip.startswith("- "):
                    next_container = []
                break
            parent[key] = next_container
            stack.append((indent, next_container))
        else:
            parent[key] = _parse_scalar(val_clean)

    return root


def extract_frontmatter(markdown_text: str) -> tuple[dict[str, Any], str]:
    """Extrait et parse le frontmatter YAML délimité par --- en tête d'un fichier SKILL.md."""
    if not markdown_text.startswith("---\n") and not markdown_text.startswith("---\r\n"):
        raise YamlParseError("Le fichier SKILL.md doit commencer par un délimiteur '---'.")

    lines = markdown_text.splitlines()
    end_idx = -1
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end_idx = idx
            break

    if end_idx == -1:
        raise YamlParseError("Délimiteur de fermeture '---' du frontmatter YAML introuvable.")

    yaml_block = "\n".join(lines[1:end_idx])
    body = "\n".join(lines[end_idx + 1 :]).strip()
    parsed = parse_simple_yaml(yaml_block)
    return parsed, body
