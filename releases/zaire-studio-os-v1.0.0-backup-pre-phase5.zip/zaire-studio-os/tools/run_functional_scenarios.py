"""Exécuteur et validateur déterministe des 5 Scénarios Fonctionnels de la Phase 4 (QA & Release).

Ce script exécute réellement les chaînes de skills, leurs scripts métier embarqués et les
contrôles de cohérence inter-livrables pour les 5 scénarios exigés :
- SCÉNARIO 1 : Conception d'un quartier fictif inspiré de Kinshasa (DST-BANDAL / Bandalungwa-Sud).
- SCÉNARIO 2 : Création d'un protagoniste complet (biographie, personnalité, famille, relations, évolution).
- SCÉNARIO 3 : Création d'une mission principale (objectifs, personnages, dialogues, étapes, conséquences).
- SCÉNARIO 4 : Simulation de circulation (taxis, motos Wewa, embouteillages, chauffeurs, interventions policières).
- SCÉNARIO 5 : Architecture de simulation de foule dans Unreal Engine 5.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools import WORKSPACE_ROOT
from tools.registry_data import SKILLS_BY_ID
from tools.validate_registry import load_source_ids, validate_knowledge_base


def run_skill_script(rel_path: str, args: list[str]) -> tuple[int, str, str]:
    """Exécute un script embarqué d'un skill et retourne (returncode, stdout, stderr)."""
    script_path = WORKSPACE_ROOT / rel_path
    proc = subprocess.run(
        [sys.executable, str(script_path), *args],
        capture_output=True,
        text=True,
        check=False,
    )
    return proc.returncode, proc.stdout.strip(), proc.stderr.strip()


def execute_all_five_scenarios() -> dict[str, dict]:
    """Exécute les 5 scénarios fonctionnels et valide leurs artefacts."""
    valid_sources = load_source_ids(WORKSPACE_ROOT)
    results: dict[str, dict] = {}

    # -------------------------------------------------------------------------
    # SCÉNARIO 1 : Quartier fictif inspiré de Kinshasa
    # -------------------------------------------------------------------------
    sc1_skills = [
        "DIR-01", "DIR-03", "DIR-04", "DIR-05",
        "WLD-02", "WLD-03", "WLD-01", "WLD-04", "WLD-05", "WLD-06",
        "GD-01", "GD-03", "GD-06",
        "ART-01", "ART-02", "ART-03", "ART-04",
        "AI-02", "AI-03", "AI-04",
        "ENG-04", "ENG-07", "DIR-06", "DIR-07",
    ]
    rc_dag1, out_dag1, err_dag1 = run_skill_script(
        "skills/00-direction/dir-01-studio-orchestrator/scripts/build_dag_plan.py",
        ["--skills", ",".join(sc1_skills)],
    )
    rc_met1, out_met1, _ = run_skill_script(
        "skills/02-world-design/wld-05-level-designer/scripts/check_spatial_metrics.py", []
    )
    rc_eco1, out_eco1, _ = run_skill_script(
        "skills/03-game-design/gd-03-economy-designer/scripts/simulate_economy.py", ["--hours", "40"]
    )
    rc_3d1, out_3d1, _ = run_skill_script(
        "skills/05-art-animation/art-04-3d-pipeline-specialist/scripts/check_3d_standards.py", []
    )
    sc1_sources = ["SRC-001", "SRC-004", "SRC-005", "SRC-008", "SRC-012", "SRC-013", "SRC-019"]
    sc1_pass = (
        rc_dag1 == 0
        and rc_met1 == 0
        and rc_eco1 == 0
        and rc_3d1 == 0
        and all(s in valid_sources for s in sc1_sources)
        and all(sk in SKILLS_BY_ID for sk in sc1_skills)
    )
    results["SCENARIO_1"] = {
        "title": "Conception d'un quartier fictif inspiré de Kinshasa (urbanisme, économie, bâtiments, circulation, activités, PNJ)",
        "classification": "PASS" if sc1_pass else "FAIL",
        "selected_skills": sc1_skills,
        "dag_waves": json.loads(out_dag1)["waves"] if rc_dag1 == 0 else err_dag1,
        "metrics_validation": out_met1,
        "economy_validation": json.loads(out_eco1) if rc_eco1 == 0 else {},
        "art_3d_validation": out_3d1,
        "verified_sources": sc1_sources,
    }

    # -------------------------------------------------------------------------
    # SCÉNARIO 2 : Protagoniste complet
    # -------------------------------------------------------------------------
    sc2_skills = [
        "DIR-01", "DIR-03", "WLD-01", "WLD-02",
        "NAR-01", "NAR-03", "NAR-05",
        "ART-01", "ART-03", "ART-04", "ART-06", "ART-05",
        "GD-01", "GD-04", "GD-05",
        "NAR-06", "PRD-03", "DIR-06", "DIR-07",
    ]
    rc_dag2, out_dag2, err_dag2 = run_skill_script(
        "skills/00-direction/dir-01-studio-orchestrator/scripts/build_dag_plan.py",
        ["--skills", ",".join(sc2_skills)],
    )
    sc2_sources = ["SRC-002", "SRC-009", "SRC-015", "SRC-019"]
    sc2_pass = (
        rc_dag2 == 0
        and all(s in valid_sources for s in sc2_sources)
        and all(sk in SKILLS_BY_ID for sk in sc2_skills)
    )
    results["SCENARIO_2"] = {
        "title": "Création d'un protagoniste complet (biographie, personnalité, famille, relations, motivations, évolution narrative)",
        "classification": "PASS" if sc2_pass else "FAIL",
        "selected_skills": sc2_skills,
        "dag_waves": json.loads(out_dag2)["waves"] if rc_dag2 == 0 else err_dag2,
        "verified_sources": sc2_sources,
    }

    # -------------------------------------------------------------------------
    # SCÉNARIO 3 : Mission principale complète
    # -------------------------------------------------------------------------
    sc3_skills = [
        "DIR-01", "DIR-03", "DIR-04", "DIR-05",
        "WLD-01", "WLD-02", "WLD-03", "WLD-04",
        "NAR-01", "NAR-03", "GD-01", "GD-02", "GD-05", "GD-07",
        "NAR-02", "NAR-04", "WLD-05", "AI-01",
        "AUD-01", "AUD-03", "AUD-04",
        "ENG-01", "ENG-02",
        "NAR-06", "PRD-04", "PRD-06", "DIR-06", "DIR-07",
    ]
    rc_dag3, out_dag3, err_dag3 = run_skill_script(
        "skills/00-direction/dir-01-studio-orchestrator/scripts/build_dag_plan.py",
        ["--skills", ",".join(sc3_skills)],
    )
    rc_dlg3, out_dlg3, _ = run_skill_script(
        "skills/01-narrative/nar-04-dialogue-designer/scripts/validate_dialogue_json.py", []
    )
    rc_l10n3, out_l10n3, _ = run_skill_script(
        "skills/06-audio-localization/aud-04-voice-localization-specialist/scripts/check_l10n_unicode.py", []
    )
    rc_xag3, out_xag3, _ = run_skill_script(
        "skills/08-production-quality/prd-06-accessibility-specialist/scripts/check_xag_compliance.py", []
    )
    sc3_sources = ["SRC-001", "SRC-002", "SRC-011", "SRC-012", "SRC-014", "SRC-018", "SRC-019"]
    sc3_pass = (
        rc_dag3 == 0
        and rc_dlg3 == 0
        and rc_l10n3 == 0
        and rc_xag3 == 0
        and all(s in valid_sources for s in sc3_sources)
    )
    results["SCENARIO_3"] = {
        "title": "Création d'une mission principale (objectifs, personnages, dialogues, étapes, conséquences, conditions de réussite)",
        "classification": "PASS" if sc3_pass else "FAIL",
        "selected_skills": sc3_skills,
        "dag_waves": json.loads(out_dag3)["waves"] if rc_dag3 == 0 else err_dag3,
        "dialogue_validation": out_dlg3,
        "localization_validation": out_l10n3,
        "xag_validation": out_xag3,
        "verified_sources": sc3_sources,
    }

    # -------------------------------------------------------------------------
    # SCÉNARIO 4 : Simulation de circulation (taxis, motos, embouteillages, chauffeurs, interventions policières)
    # -------------------------------------------------------------------------
    sc4_skills = [
        "DIR-01", "DIR-03", "DIR-04", "DIR-05",
        "WLD-01", "WLD-02", "WLD-03", "WLD-04",
        "GD-01", "GD-05", "GD-06",
        "NAR-02", "NAR-03", "GD-02", "NAR-04", "WLD-05",
        "ART-01", "ART-04", "WLD-06", "ART-02",
        "AI-01", "AI-03", "AI-04",
        "AUD-01", "AUD-02",
        "ENG-04", "ENG-05", "ENG-07",
        "PRD-04", "PRD-05", "DIR-07",
    ]
    rc_dag4, out_dag4, err_dag4 = run_skill_script(
        "skills/00-direction/dir-01-studio-orchestrator/scripts/build_dag_plan.py",
        ["--skills", ",".join(sc4_skills)],
    )
    rc_perf4, out_perf4, _ = run_skill_script(
        "skills/07-engineering/eng-07-performance-engineer/scripts/check_perf_budget.py", []
    )
    sc4_sources = ["SRC-004", "SRC-005", "SRC-015", "SRC-018", "SRC-020"]
    sc4_pass = (
        rc_dag4 == 0
        and rc_perf4 == 0
        and all(s in valid_sources for s in sc4_sources)
    )
    results["SCENARIO_4"] = {
        "title": "Conception d'une simulation de circulation (taxis, motos Wewa, embouteillages, chauffeurs, interventions policières)",
        "classification": "PASS" if sc4_pass else "FAIL",
        "selected_skills": sc4_skills,
        "dag_waves": json.loads(out_dag4)["waves"] if rc_dag4 == 0 else err_dag4,
        "performance_validation": json.loads(out_perf4) if rc_perf4 == 0 else {},
        "verified_sources": sc4_sources,
    }

    # -------------------------------------------------------------------------
    # SCÉNARIO 5 : Architecture de simulation de foule dans Unreal Engine
    # -------------------------------------------------------------------------
    sc5_skills = [
        "DIR-01", "DIR-03", "DIR-04", "DIR-05",
        "WLD-01", "WLD-02", "WLD-03", "WLD-04",
        "NAR-01", "NAR-03",
        "ART-01", "ART-04", "ART-03", "ART-08",
        "AI-02", "AI-04",
        "ENG-01", "ENG-06", "ENG-07",
        "PRD-04", "PRD-05", "DIR-07",
    ]
    rc_dag5, out_dag5, err_dag5 = run_skill_script(
        "skills/00-direction/dir-01-studio-orchestrator/scripts/build_dag_plan.py",
        ["--skills", ",".join(sc5_skills)],
    )
    rc_mass5, out_mass5, _ = run_skill_script(
        "skills/04-ai-simulation/ai-02-crowd-simulation-specialist/scripts/check_mass_budget.py",
        ["--hydrated", "18", "--lod1", "180", "--lod2", "420"],
    )
    sc5_sources = ["SRC-001", "SRC-004", "SRC-009", "SRC-013", "SRC-020"]
    sc5_pass = (
        rc_dag5 == 0
        and rc_mass5 == 0
        and all(s in valid_sources for s in sc5_sources)
    )
    results["SCENARIO_5"] = {
        "title": "Conception d'une architecture de simulation de foule dans Unreal Engine 5",
        "classification": "PASS" if sc5_pass else "FAIL",
        "selected_skills": sc5_skills,
        "dag_waves": json.loads(out_dag5)["waves"] if rc_dag5 == 0 else err_dag5,
        "mass_budget_validation": json.loads(out_mass5) if rc_mass5 == 0 else {},
        "verified_sources": sc5_sources,
    }

    return results


def main() -> int:
    kb_errors = validate_knowledge_base(WORKSPACE_ROOT)
    if kb_errors:
        print(f"[ERREUR] Knowledge Base invalide : {kb_errors}")
        return 1
    results = execute_all_five_scenarios()
    all_passed = all(v["classification"] == "PASS" for v in results.values())
    print(json.dumps(results, indent=2, ensure_ascii=False))
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
