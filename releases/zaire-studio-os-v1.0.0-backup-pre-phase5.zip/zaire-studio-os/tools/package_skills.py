"""Générateur d'index et packager ZIP (Claude.ai & Archive Système Complète).

Produit :
1. `docs/skills-index.md` : Table de bord en temps réel des skills implémentés et vérifiés par département.
2. `releases/skills/<skill-name>.zip` : 57 archives ZIP autonomes prêtes à être importées dans Claude.ai.
3. `releases/zaire-studio-os-v<VERSION>-full.zip` : Archive complète du système ZAÏRE STUDIO OS.
"""

from __future__ import annotations

import sys
import zipfile
from pathlib import Path

if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools import WORKSPACE_ROOT
from tools.lint_skills import lint_single_skill
from tools.registry_data import CANONICAL_SKILLS


def update_skills_index(workspace: Path = WORKSPACE_ROOT) -> Path:
    """Met à jour `docs/skills-index.md` avec l'état réel d'implémentation et de validation."""
    docs_dir = workspace / "docs"
    docs_dir.mkdir(parents=True, exist_ok=True)
    index_path = docs_dir / "skills-index.md"

    implemented = 0
    validated = 0
    rows: list[str] = []

    for spec in CANONICAL_SKILLS:
        skill_dir = workspace / "skills" / spec.department / spec.slug
        if skill_dir.exists() and (skill_dir / "SKILL.md").exists():
            implemented += 1
            errs = lint_single_skill(skill_dir)
            if not errs:
                validated += 1
                status_badge = "CONFIRMED (Tests OK)"
            else:
                status_badge = f"ERROR ({len(errs)})"
            has_scripts = "Oui" if (skill_dir / "scripts").exists() else "Non"
        else:
            status_badge = "PENDING"
            has_scripts = "-"

        rows.append(
            f"| `{spec.skill_id}` | `{spec.slug}` | `{spec.department}` | Strate {spec.stratum} | {has_scripts} | **{status_badge}** |"
        )

    content = [
        "# Index Maître des Skills — ZAÏRE STUDIO OS (`skills-index.md`)",
        "",
        f"- **Progression Globale** : **{implemented} / {len(CANONICAL_SKILLS)}** skills implémentés",
        f"- **Skills Validés (Linter + YAML + Références)** : **{validated} / {len(CANONICAL_SKILLS)}**",
        "",
        "| ID | Nom du Skill (Kebab-Case) | Département | Strate DAG | Scripts Dédiés | Statut d'Implémentation |",
        "| :--- | :--- | :--- | :--- | :--- | :--- |",
        *rows,
        "",
    ]
    index_path.write_text("\n".join(content), encoding="utf-8")
    return index_path


def package_individual_skill(skill_dir: Path, output_dir: Path) -> Path:
    """Crée une archive ZIP individuelle compatible Claude.ai pour un skill."""
    output_dir.mkdir(parents=True, exist_ok=True)
    slug = skill_dir.name
    zip_path = output_dir / f"{slug}.zip"

    with zipfile.ZipFile(zip_path, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file_path in sorted(skill_dir.rglob("*")):
            if file_path.is_file() and "__pycache__" not in file_path.parts:
                arcname = f"{slug}/{file_path.relative_to(skill_dir).as_posix()}"
                zf.write(file_path, arcname=arcname)

    return zip_path


def package_department_bundle(dept_dir: Path, output_dir: Path) -> Path:
    """Crée une archive ZIP regroupant tous les skills d'un département."""
    output_dir.mkdir(parents=True, exist_ok=True)
    dept_name = dept_dir.name
    zip_path = output_dir / f"{dept_name}.zip"

    with zipfile.ZipFile(zip_path, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file_path in sorted(dept_dir.rglob("*")):
            if file_path.is_file() and "__pycache__" not in file_path.parts:
                arcname = f"{dept_name}/{file_path.relative_to(dept_dir).as_posix()}"
                zf.write(file_path, arcname=arcname)

    return zip_path


def package_all_releases(workspace: Path = WORKSPACE_ROOT) -> tuple[list[Path], list[Path], Path]:
    """Génère les archives individuelles Claude.ai, les archives par département et l'archive globale."""
    version_file = workspace / "VERSION"
    version = version_file.read_text(encoding="utf-8").strip() if version_file.exists() else "1.0.0"

    releases_dir = workspace / "releases"
    skills_zip_dir = releases_dir / "skills"
    depts_zip_dir = releases_dir / "departments"
    skills_zip_dir.mkdir(parents=True, exist_ok=True)
    depts_zip_dir.mkdir(parents=True, exist_ok=True)

    individual_zips: list[Path] = []
    department_zips: list[Path] = []
    skills_root = workspace / "skills"
    if skills_root.exists():
        for dept_dir in sorted(skills_root.glob("*")):
            if dept_dir.is_dir():
                department_zips.append(package_department_bundle(dept_dir, depts_zip_dir))
        for skill_dir in sorted(skills_root.glob("*/*")):
            if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
                individual_zips.append(package_individual_skill(skill_dir, skills_zip_dir))

    full_zip_path = releases_dir / f"zaire-studio-os-v{version}-full.zip"
    included_roots = (
        "README.md",
        "CLAUDE.md",
        "CHANGELOG.md",
        "VERSION",
        "research",
        "architecture",
        "knowledge",
        "schemas",
        "templates",
        "skills",
        "tools",
        "tests",
        "docs",
        "audit",
    )

    with zipfile.ZipFile(full_zip_path, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for item_name in included_roots:
            target = workspace / item_name
            if not target.exists():
                continue
            if target.is_file():
                zf.write(target, arcname=f"zaire-studio-os/{target.name}")
            else:
                for subfile in sorted(target.rglob("*")):
                    if subfile.is_file() and "__pycache__" not in subfile.parts:
                        rel = subfile.relative_to(workspace).as_posix()
                        zf.write(subfile, arcname=f"zaire-studio-os/{rel}")

    return individual_zips, department_zips, full_zip_path


def main() -> int:
    idx_path = update_skills_index(WORKSPACE_ROOT)
    ind_zips, dept_zips, full_zip = package_all_releases(WORKSPACE_ROOT)
    print(f"[OK] Index mis à jour : {idx_path.relative_to(WORKSPACE_ROOT)}")
    print(f"[OK] {len(ind_zips)} archive(s) ZIP individuelle(s) générée(s) dans releases/skills/")
    print(f"[OK] {len(dept_zips)} archive(s) ZIP départementale(s) générée(s) dans releases/departments/")
    print(f"[OK] Archive globale générée : {full_zip.relative_to(WORKSPACE_ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
