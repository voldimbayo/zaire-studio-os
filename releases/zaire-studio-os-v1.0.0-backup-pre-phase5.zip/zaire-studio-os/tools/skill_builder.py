"""Moteur modulaire de génération et de maintenance des Agent Skills de ZAÏRE STUDIO OS.

Chaque département dispose d'un module de spécifications riches (`tools/departments/dept_*.py`)
définissant pour chaque skill :
- Ses métadonnées YAML (entrées, sorties, dépendances amont, strate DAG).
- Ses conditions d'activation et limites strictes de périmètre.
- Sa procédure opérationnelle pas-à-pas et ses règles de décision déterministes.
- Ses fichiers `references/domain-guidelines.md`, `templates/<deliverable>`,
  `examples/sample-deliverable.md` et optionnellement `scripts/<tool>.py`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import sys

if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from tools import WORKSPACE_ROOT, resolve_safe_path
from tools.registry_data import SKILLS_BY_ID


@dataclass(frozen=True)
class SkillBlueprint:
    skill_id: str
    description: str
    inputs: tuple[str, ...]
    outputs: tuple[str, ...]
    activation_triggers: tuple[str, ...]
    scope_boundaries: tuple[str, ...]
    operational_procedures: tuple[str, ...]
    decision_rules: tuple[tuple[str, str, str], ...]  # (Condition, Action, Escalation/Fallback)
    acceptance_criteria: tuple[str, ...]
    validation_auditors: tuple[str, ...]
    reference_filename: str
    reference_content: str
    template_filename: str
    template_content: str
    example_filename: str
    example_content: str
    scripts: dict[str, str] = field(default_factory=dict)


def render_skill_markdown(bp: SkillBlueprint) -> str:
    """Assemble le fichier SKILL.md conforme aux spécifications Anthropic Agent Skills."""
    spec = SKILLS_BY_ID[bp.skill_id]
    inputs_yaml = "\n".join(f'    - "{item}"' for item in bp.inputs)
    outputs_yaml = "\n".join(f'    - "{item}"' for item in bp.outputs)
    if spec.upstream_ids:
        upstreams_yaml = "\n" + "\n".join(f'    - "{uid}"' for uid in spec.upstream_ids)
    else:
        upstreams_yaml = " []"

    triggers_md = "\n".join(f"- {t}" for t in bp.activation_triggers)
    limits_md = "\n".join(f"- **Interdiction / Limite** : {lim}" for lim in bp.scope_boundaries)
    procedures_md = "\n".join(
        f"{idx}. {step}" for idx, step in enumerate(bp.operational_procedures, start=1)
    )
    decision_rows = "\n".join(
        f"| {cond} | {act} | {esc} |" for cond, act, esc in bp.decision_rules
    )
    criteria_md = "\n".join(f"- [ ] {crit}" for crit in bp.acceptance_criteria)
    auditors_str = ", ".join(f"`{aud}`" for aud in bp.validation_auditors)
    upstreams_display = (
        ", ".join(f"`{u}`" for u in spec.upstream_ids)
        if spec.upstream_ids
        else "Aucune (Point d'entrée racine Strate 0)"
    )

    scripts_section = ""
    if bp.scripts:
        script_lines = [
            f"- `scripts/{sname}` : Script exécutable déterministe associé à `{spec.skill_id}`."
            for sname in sorted(bp.scripts.keys())
        ]
        scripts_section = "\n" + "\n".join(script_lines)

    return f"""---
name: {spec.slug}
description: "{bp.description}"
license: "Proprietary - ZAÏRE STUDIO OS"
compatibility: "Claude.ai, Claude Code, Google Antigravity, Cursor"
metadata:
  id: {spec.skill_id}
  department: {spec.department}
  stratum: {spec.stratum}
  version: "1.0.0"
  inputs:
{inputs_yaml}
  outputs:
{outputs_yaml}
  upstream_dependencies:{upstreams_yaml}
---

# `{spec.skill_id}` — {spec.title} (`{spec.slug}`)

## 1. Conditions d'Utilisation & Périmètre Opérationnel

Ce skill appartient au département **`{spec.department}`** (Strate DAG **{spec.stratum}**) de **ZAÏRE STUDIO OS**.

### Déclencheurs d'Activation
{triggers_md}

### Contrats d'Interface (Inputs / Outputs)
- **Entrées requises** : {', '.join(f'`{i}`' for i in bp.inputs)}
- **Sorties produites** : {', '.join(f'`{o}`' for o in bp.outputs)}
- **Dépendances Amont (DAG)** : {upstreams_display}

---

## 2. Limites Stricte de Responsabilité (Scope Guard)

{limits_md}
- **Règle d'Intégrité Référentielle** : Ne jamais référencer une entité du monde de Kinshasa (Personnage `CHR-*`, Famille `FAM-*`, Organisation `ORG-*`, Commune `DST-*`, Lieu `LOC-*`, Mission `MSN-*`, Objet `ITM-*`, Véhicule `VEH-*`, Système `SYS-*`) sans vérifier son statut dans `knowledge/entities-registry.csv`. Toute information factuelle manquante doit être marquée **`RESEARCH_REQUIRED`**.

---

## 3. Procédures Opérationnelles Standardisées (SOP)

Exécuter séquentiellement les étapes suivantes lors de toute activation du skill :

{procedures_md}

---

## 4. Règles de Décision & Arbre d'Arbitrage

| Condition Détectée | Décision / Action Obligatoire | Escalade & Protocole de Repli |
| :--- | :--- | :--- |
{decision_rows}

---

## 5. Chargement Progressif des Références, Modèles et Scripts

Afin d'optimiser la fenêtre de contexte, chargez uniquement à la demande les ressources suivantes incluses dans ce skill :

- **Référentiel Métier & Checklists Techniques** : `references/{bp.reference_filename}`
- **Modèle Officiel de Livrable** : `templates/{bp.template_filename}`
- **Exemple Complet d'Exécution (Input/Output)** : `examples/{bp.example_filename}`{scripts_section}
- **Référentiel Partagé Studio (Couche 2)** : `knowledge/entities-registry.csv`, `knowledge/technical-specs/performance-budgets.csv`, `knowledge/technical-specs/spatial-metrics.md`

---

## 6. Exemples Concrets d'Entrées et Sorties

Consultez le fichier `examples/{bp.example_filename}` pour un cas réel complet appliqué à **ZAÏRE (Kinshasa)** comprenant l'enveloppe de tâche (`Task Envelope`) reçue, l'artefact généré conforme à `templates/{bp.template_filename}` et le paquet de passation (`Handoff Packet`).

---

## 7. Critères de Validation & Definition of Done (DoD)

Un livrable produit par `{spec.skill_id}` ne peut passer du statut `PROPOSED` au statut `CONFIRMED` que si tous les contrôles suivants sont validés :

{criteria_md}
- **Validation Croisée Obligatoire** : Soumettre le Handoff Packet aux skills auditeurs : {auditors_str}.
"""


def write_skill_from_blueprint(bp: SkillBlueprint, workspace: Path = WORKSPACE_ROOT) -> Path:
    """Crée sur disque le dossier complet du skill et ses sous-fichiers."""
    spec = SKILLS_BY_ID[bp.skill_id]
    skill_dir = workspace / "skills" / spec.department / spec.slug
    skill_dir.mkdir(parents=True, exist_ok=True)

    skill_md_path = skill_dir / "SKILL.md"
    skill_md_path.write_text(render_skill_markdown(bp), encoding="utf-8")

    ref_path = resolve_safe_path(skill_dir, f"references/{bp.reference_filename}")
    ref_path.parent.mkdir(parents=True, exist_ok=True)
    ref_path.write_text(bp.reference_content.strip() + "\n", encoding="utf-8")

    tpl_path = resolve_safe_path(skill_dir, f"templates/{bp.template_filename}")
    tpl_path.parent.mkdir(parents=True, exist_ok=True)
    tpl_path.write_text(bp.template_content.strip() + "\n", encoding="utf-8")

    ex_path = resolve_safe_path(skill_dir, f"examples/{bp.example_filename}")
    ex_path.parent.mkdir(parents=True, exist_ok=True)
    ex_path.write_text(bp.example_content.strip() + "\n", encoding="utf-8")

    for script_name, script_code in bp.scripts.items():
        sc_path = resolve_safe_path(skill_dir, f"scripts/{script_name}")
        sc_path.parent.mkdir(parents=True, exist_ok=True)
        sc_path.write_text(script_code.strip() + "\n", encoding="utf-8")

    return skill_dir
