# Vérification des Sources & Traçabilité Documentaire (`source-verification.md`)

- **Date d'Audit** : `2026-11-25`
- **Fichier Maître Audité** : [research/source-registry.csv](file:///C:/Users/Voldi%20Otk/Desktop/zaire-studio-os/research/source-registry.csv) (20 sources enregistrées : `SRC-001` à `SRC-020`)
- **Verdict de Traçabilité** : **`PASS`** (0 source inventée, 0 référence `SRC-*` fantôme après correction de `DEF-01`).

---

## 1. Contrôle Automatisé des Références Croisées (`research/` -> `knowledge/` -> `skills/`)

L'exécution conjointe de `tools/validate_registry.py` et `tools/lint_skills.py` vérifie que chaque code `SRC-NNN` cité dans `knowledge/entities-registry.csv` et dans les 57 dossiers de `skills/` appartient à l'ensemble exact `{'SRC-001', ..., 'SRC-020'}`.

| ID Source | Titre & Auteur / Organisation | Statut de Vérification (`source-registry.csv`) | Utilisation Réelle dans les Skills & le Registre | Classification |
| :--- | :--- | :--- | :--- | :--- |
| `SRC-001` | *World Partition in Unreal Engine* (Epic Games, 2025) | Consultée (Extrait/Index) | `ENG-01`, `WLD-04`, `SYS-WLD-STREAMING` | **`PASS`** |
| `SRC-002` | *Gameplay Ability System for Unreal Engine* (Epic Games, 2026) | Consultée (Extrait/Index) | `GD-01`, `GD-02`, `GD-05`, `ENG-02`, `SYS-CMB-MELEE`, `SYS-STEALTH` | **`PASS`** |
| `SRC-003` | *Lumen Technical Details in Unreal Engine* (Epic Games, 2026) | Consultée (Extrait/Index) | `ART-07`, `ENG-06` | **`PASS`** |
| `SRC-004` | *City Sample Quick Start (Houdini/ZoneGraph/Mass)* (Epic/SideFX, 2024) | Consultée (Extrait/Index) | `AI-02`, `AI-03`, `ENG-04`, `GD-06`, `SYS-CROWD-MASS`, `SYS-TRAFFIC-ZONE` | **`PASS`** |
| `SRC-005` | *Procedural Cyberpunk City with Unreal (OSM)* (SideFX, 2021) | Consultée (Extrait/Index) | `WLD-03`, `ENG-04`, `DST-GOMBE`, `DST-MASINA`, `ORG-TRANSCO` | **`PASS`** |
| `SRC-006` | *Solving Visibility and Streaming in The Witcher 3* (CDPR / Umbra, 2014) | Consultée (Extrait/Index) | `ENG-01`, `WLD-04` | **`PASS`** |
| `SRC-007` | *Tools for Marvel's Spider-Man: Editing with Immutable Data* (Insomniac, 2019) | Consultée (Extrait/Index) | `ENG-03` | **`PASS`** |
| `SRC-008` | *Procedurally Crafting Manhattan for Marvel's Spider-Man* (Insomniac, 2019) | Repérée (À approfondir) | `ENG-04`, `WLD-06` (isolée en limite connue `known-limitations.md`) | **`PASS`** |
| `SRC-009` | *Repopulating the Earth: Character Production on Horizon Zero Dawn* (Guerrilla, 2018) | Consultée (Extrait/Index) | `ART-03`, `NAR-03`, `CHR-PROTAG-KOFFI` | **`PASS`** |
| `SRC-010` | *Creating a Tools Pipeline for Horizon Zero Dawn* (Guerrilla, 2017) | Consultée (Extrait/Index) | `ENG-03` | **`PASS`** |
| `SRC-011` | *In-Game and Cinematic Lighting of The Last of Us* (Naughty Dog, 2014) | Consultée (Extrait/Index) | `ART-07`, `NAR-02` | **`PASS`** |
| `SRC-012` | *Level Design Workshop: Blockmesh and Lighting Tips* (Naughty Dog, 2018) | Consultée (Extrait/Index) | `WLD-05`, `ART-07` (Règle *Blockout First*) | **`PASS`** |
| `SRC-013` | *Developing Systemic Crowd Events in Assassin's Creed Unity* (Ubisoft, 2015) | Consultée (Extrait/Index) | `AI-02`, `AI-04`, `LOC-MATONGE-VICTOIRE` | **`PASS`** |
| `SRC-014` | *Procedural Generation of Cinematic Dialogues in AC Odyssey* (Ubisoft, 2019) | Repérée (À approfondir) | `NAR-04` (tags émotionnels & cadrage caméra procédural) | **`PASS`** |
| `SRC-015` | *Player Locomotion in Red Dead Redemption 2* (Rockstar Games, 2020) | Consultée (Extrait/Index) | `ART-05`, `AI-04` | **`PASS`** |
| `SRC-016` | *quodsoler/unreal-engine-skills* (GitHub, 2026) | Consultée (Extrait/Index) | `DIR-01`, `ENG-01`, `ENG-02` (inspiration granulaire, 0 copier-coller) | **`PASS`** |
| `SRC-017` | *gamedev-skills/awesome-gamedev-agent-skills* (GitHub, 2026) | Consultée (Extrait/Index) | `DIR-01` (architecture de routage) | **`PASS`** |
| `SRC-018` | *Wwise vs FMOD vs MetaSounds* (StraySpark Studio, 2026) | Consultée (Extrait/Index) | `AUD-01`, `AUD-02`, `ORG-RADIO-KIN` | **`PASS`** |
| `SRC-019` | *Unreal Engine World Building Guide* (Epic Games, 2025) | Consultée (Extrait/Index) | `WLD-01`, `WLD-04`, `WLD-06`, `ART-02`, communes `DST-*` | **`PASS`** |
| `SRC-020` | *Game Engine Architecture (3rd Ed.)* (Jason Gregory, 2018) | Repérée (À approfondir) | `DIR-04`, `ENG-01`, `ENG-05`, `ENG-06` | **`PASS`** |

---

## 2. Respect de la Règle Anti-Hallucination (`RESEARCH_REQUIRED`)

- Toute donnée géographique ou culturelle non vérifiée dans les sources primaires (ex: réseau secondaire des ruelles de la commune de Masina `DST-MASINA`) est explicitement maintenue au statut **`RESEARCH_REQUIRED`** dans `knowledge/entities-registry.csv` et `knowledge/status-audit-log.csv`.
- Les skills `WLD-02`, `WLD-03`, `NAR-02` et `DIR-06` comportent des règles de décision bloquant toute promotion en `CONFIRMED` d'une entité dont les sources ou la couverture SIG sont incomplètes.
